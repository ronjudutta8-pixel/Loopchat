// sw.js
self.addEventListener('push', function(event) {
  if (event.data) {
    let data = {};
    try {
      data = event.data.json();
    } catch (e) {
      data = { title: 'New Message', body: event.data.text() };
    }
    
    const options = {
      body: data.body,
      icon: '/favicon.ico',
      badge: '/favicon.ico',
      data: data.data,
      vibrate: [200, 100, 200, 100, 200, 100, 200],
      tag: data.tag || 'incoming-call',
      renotify: data.renotify || false,
      requireInteraction: data.requireInteraction || false,
      actions: [
        { action: 'answer', title: 'Answer' },
        { action: 'decline', title: 'Decline' }
      ]
    };

    event.waitUntil(
      self.registration.showNotification(data.title || 'Incoming Call', options)
    );
  }
});

self.addEventListener('notificationclick', function(event) {
  event.notification.close();

  const callId = event.notification.data?.callId;
  let urlToOpen = event.notification.data?.url || '/';

  if (event.action === 'answer') {
    urlToOpen += '&accept=true';
  } else if (event.action === 'decline') {
    // We could call an API here to decline, but for now we just won't open the app 
    // or we open it with decline=true if we want to handle it in UI
    return;
  }

  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then(windowClients => {
      // Check if there is already a window open
      for (let client of windowClients) {
        // If we find an open window, navigate it to the call URL
        if ('focus' in client) {
          client.navigate(urlToOpen);
          return client.focus();
        }
      }
      // If not, open a new one
      if (clients.openWindow) {
        return clients.openWindow(urlToOpen);
      }
    })
  );
});
