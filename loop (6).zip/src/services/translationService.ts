import { GoogleGenAI } from "@google/genai";

let aiInstance: GoogleGenAI | null = null;

function getAI() {
  if (!aiInstance) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is not configured");
    }
    aiInstance = new GoogleGenAI({ apiKey });
  }
  return aiInstance;
}

export async function translateText(text: string, targetLanguageCode: string): Promise<string> {
  if (!text.trim()) return "";
  
  try {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Translate the following text to ${targetLanguageCode}. Only return the translated text without any explanations.\n\nText: ${text}`,
    });

    return response.text?.trim() || "Translation failed";
  } catch (error) {
    console.error("Translation error:", error);
    return `Translation error: ${error instanceof Error ? error.message : "Unknown error"}`;
  }
}
