/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './components/AuthContext';
import { Sidebar } from './components/Sidebar';
import { ChatArea } from './components/ChatArea';
import { Login } from './components/Login';
import { ChatThread, UserProfile } from './types';
import { motion, AnimatePresence } from 'motion/react';
import { collection, query, where, onSnapshot, doc, getDoc } from 'firebase/firestore';
import { db } from './components/firebase';
import { CallInterface } from './components/CallInterface';
import { registerServiceWorker, subscribeToPush } from './push';

function LoopApp() {
  const { user, profile, loading } = useAuth();
  const [selectedChat, setSelectedChat] = useState<ChatThread | null>(null);
  const [activeCall, setActiveCall] = useState<{ 
    type: 'audio' | 'video', 
    incoming: boolean, 
    otherUser: UserProfile,
    callId: string,
    autoAccept?: boolean
  } | null>(null);

  useEffect(() => {
    if (user) {
      registerServiceWorker().then(() => {
        subscribeToPush(user.uid);
      });
    }
  }, [user?.uid]);

  useEffect(() => {
    // Handle incoming call from URL params (Deep Link from Notification)
    const params = new URLSearchParams(window.location.search);
    const callId = params.get('callId');
    const autoAccept = params.get('accept') === 'true';
    
    if (callId && user && !activeCall) {
      getDoc(doc(db, 'calls', callId)).then(async (snap) => {
        if (snap.exists()) {
          const data = snap.data();
          if (data.status === 'ringing' && data.receiverId === user.uid) {
            const callerSnap = await getDoc(doc(db, 'users', data.callerId));
            const callerProfile = callerSnap.exists() ? callerSnap.data() as UserProfile : { uid: data.callerId, displayName: 'User', photoURL: '' } as UserProfile;
            
            setActiveCall({
              type: data.type,
              incoming: true,
              otherUser: callerProfile,
              callId: callId,
              autoAccept // Pass the flag
            });
            
            // Clean up URL
            window.history.replaceState({}, '', '/');
          }
        }
      });
    }
  }, [user, activeCall]);

  useEffect(() => {
    if (!user) {
      setActiveCall(null);
      return;
    }

    console.log("Subscribing to incoming calls for", user.uid);

    // Listen for any calls where user is receiver
    const q = query(
      collection(db, 'calls'),
      where('receiverId', '==', user.uid)
    );

    const unsubscribe = onSnapshot(q, async (snap) => {
      // Find the first ringing call
      const ringingCall = snap.docs.find(d => d.data().status === 'ringing');
      
      if (!ringingCall) {
        setActiveCall(prev => {
          if (prev?.incoming) {
            const thisCall = snap.docs.find(d => d.id === prev.callId);
            const status = thisCall?.data()?.status;
            if (!thisCall || status === 'ended' || status === 'missed') {
              return null;
            }
          }
          return prev;
        });
        return;
      }
      
      const callData = ringingCall.data();
      
      // Check if caller is blocked
      if (profile?.blockedUsers?.includes(callData.callerId)) {
        console.log("Blocking incoming call from blocked user:", callData.callerId);
        return;
      }
      
      setActiveCall(prev => {
        if (prev?.callId === ringingCall.id) return prev;
        return {
          type: callData.type,
          incoming: true,
          otherUser: { uid: callData.callerId, displayName: 'Incoming Call...', photoURL: '' } as UserProfile,
          callId: ringingCall.id
        };
      });

      try {
        const callerSnap = await getDoc(doc(db, 'users', callData.callerId));
        if (callerSnap.exists()) {
          const profileData = callerSnap.data() as UserProfile;
          setActiveCall(prev => {
            if (prev?.callId === ringingCall.id) {
              return { ...prev, otherUser: profileData };
            }
            return prev;
          });
        }
      } catch (err) {
        console.error("Error fetching caller profile:", err);
      }
    }, (error) => {
      import('./components/firebase').then(({ handleFirestoreError, OperationType }) => {
        handleFirestoreError(error, OperationType.LIST, 'calls');
      }).catch(() => {
        console.error("App Call Listener Error:", error);
      });
    });

    return unsubscribe;
  }, [user?.uid]);

  const handleStartCall = (type: 'audio' | 'video', targetUser: UserProfile) => {
    setActiveCall({
      type,
      incoming: false,
      otherUser: targetUser,
      callId: ''
    });
  };

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center bg-gray-50">
        <div className="h-12 w-12 animate-spin rounded-full border-4 border-emerald-500 border-t-transparent" />
      </div>
    );
  }

  if (!user) {
    return <Login />;
  }

  return (
    <div className="flex h-screen w-full overflow-hidden bg-gray-100 text-slate-900">
      <div className="flex w-full overflow-hidden shadow-2xl md:mx-auto md:my-4 md:h-[calc(100vh-2rem)] md:max-w-6xl md:rounded-lg">
        {/* Sidebar */}
        <div className={`w-full md:w-1/3 lg:w-1/4 bg-white border-r border-slate-200 flex-shrink-0 ${selectedChat ? 'hidden md:flex' : 'flex'} flex-col h-full`}>
          <Sidebar 
            onSelectChat={setSelectedChat} 
            selectedChatId={selectedChat?.id} 
            onStartCall={handleStartCall}
          />
        </div>

        {/* Chat Area */}
        <div className={`flex-grow h-full bg-[#f0f2f5] relative ${!selectedChat ? 'hidden md:flex' : 'flex'} flex-col`}>
          <AnimatePresence mode="wait">
            {selectedChat ? (
              <motion.div
                key={selectedChat.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
                className="flex-grow h-full overflow-hidden"
              >
                <ChatArea chat={selectedChat} onBack={() => setSelectedChat(null)} />
              </motion.div>
            ) : (
              <div className="flex h-full flex-col items-center justify-center p-8 text-center bg-[#f0f2f5]">
                <div className="mb-6 h-32 w-32 rounded-full bg-gradient-to-br from-indigo-600 to-violet-600 flex items-center justify-center shadow-2xl relative">
                  <div className="absolute inset-0 rounded-full bg-indigo-500/20 animate-ping"></div>
                  <svg className="h-16 w-16 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                  </svg>
                </div>
                <h1 className="text-4xl font-black text-indigo-900 tracking-tighter uppercase italic">
                  LO<span className="text-indigo-600">OP</span>
                </h1>
                <p className="mt-2 max-w-sm text-slate-500 font-bold uppercase tracking-widest text-xs">
                  Infinite Connections | Real Conversations
                </p>
                <div className="mt-8 p-4 bg-indigo-50 rounded-xl border border-indigo-100 flex items-center text-[10px] text-indigo-700 font-bold uppercase tracking-widest">
                  <svg className="h-4 w-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
                  </svg>
                  Privacy Protected & Encrypted
                </div>
              </div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Global Call Overlay */}
      {activeCall && (
        <CallInterface 
          key={activeCall.callId || 'new-call'}
          type={activeCall.type}
          otherUser={activeCall.otherUser}
          incoming={activeCall.incoming}
          existingCallId={activeCall.callId}
          autoAccept={activeCall.autoAccept}
          onClose={() => setActiveCall(null)}
        />
      )}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <LoopApp />
    </AuthProvider>
  );
}

