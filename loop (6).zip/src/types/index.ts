export interface UserProfile {
  uid: string;
  displayName: string;
  photoURL: string;
  email: string;
  phoneNumber?: string;
  status?: string;
  lastSeen?: number;
  isOnline?: boolean;
  blockedUsers?: string[];
  favoriteIds?: string[];
}

export interface Message {
  id: string;
  senderId: string;
  senderName: string;
  text: string;
  timestamp: number;
  type: 'text' | 'image' | 'video' | 'call_info' | 'audio';
  fileUrl?: string; // For base64 or external URLs
  duration?: number; // For audio
  deletedFor?: string[];
  isDeletedForEveryone?: boolean;
  readBy?: string[];
}

export interface ChatThread {
  id: string;
  participants: string[];
  participantDetails?: Record<string, UserProfile>;
  isGroup?: boolean;
  groupName?: string;
  groupPhotoURL?: string;
  createdBy?: string;
  admins?: string[];
  lastMessage?: {
    text: string;
    timestamp: number;
    senderId: string;
    senderName?: string;
  };
  updatedAt: number;
  createdAt: number;
}

export interface CallSession {
  id: string;
  callerId: string;
  receiverId: string;
  status: 'ringing' | 'active' | 'ended' | 'missed';
  type: 'audio' | 'video';
  createdAt: number;
  offer?: any;
  answer?: any;
}
