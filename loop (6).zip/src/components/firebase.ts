import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, signInWithPopup } from 'firebase/auth';
import { getFirestore, doc, getDocFromServer, collection, addDoc, updateDoc, setDoc, query, where, onSnapshot, orderBy, serverTimestamp, Timestamp, limit } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

// Connection Test
async function testConnection() {
  console.log("Starting Firebase connection test for project:", firebaseConfig.projectId);
  try {
    // Try to get a doc from a non-existent collection just to check connectivity
    // Use getDocFromServer to bypass cache
    await getDocFromServer(doc(db, '_connection_test_', 'check'));
    console.log("Firebase connection successful");
  } catch (error: any) {
    if (error.code === 'unavailable') {
      console.error("Firestore backend is currently unreachable. This may be because the database is still provisioning or there is a network issue.");
    } else if (error.code === 'permission-denied') {
      console.log("Firestore connection test: Permissions denied (expected if not logged in), but backend is reachable.");
    } else {
      console.error("Firestore connection test encountered an error:", error.code, error.message);
    }
  }
}

testConnection();

// Error Handling Utility
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
  }
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  // If not logged in, errors are expected and don't need structured logging
  if (!auth.currentUser) {
    console.warn(`Firestore ${operationType} failed while unauthenticated for path: ${path}`);
    return;
  }

  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser.uid,
      email: auth.currentUser.email,
      emailVerified: auth.currentUser.emailVerified,
      isAnonymous: auth.currentUser.isAnonymous,
    },
    operationType,
    path
  }
  const errorMsg = JSON.stringify(errInfo);
  console.error('Firestore Error: ', errorMsg);
  throw new Error(errorMsg);
}

// Auth Helper
export const signIn = () => signInWithPopup(auth, googleProvider);
export const signOut = () => auth.signOut();
