import React, { useEffect, useRef, useState } from 'react';
import { useAuth } from './AuthContext';
import { UserProfile } from '../types';
import { useLanguage } from './LanguageContext';
import { PhoneOff, Mic, MicOff, Video, VideoOff, Volume2, Volume1, VolumeX, Phone, Monitor, Minimize2, Maximize2, Settings, Sliders, RefreshCw, Clock } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { collection, addDoc, doc, updateDoc, onSnapshot, deleteDoc, setDoc, getDoc, collectionGroup, query, where, serverTimestamp } from 'firebase/firestore';
import { db } from './firebase';
import { notifyCall } from '../push';

interface CallInterfaceProps {
  type: 'audio' | 'video';
  otherUser: UserProfile;
  incoming: boolean;
  onClose: () => void;
  existingCallId?: string;
  autoAccept?: boolean;
}

const servers = {
  iceServers: [
    {
      urls: ['stun:stun1.l.google.com:19302', 'stun:stun2.l.google.com:19302'],
    },
  ],
  iceCandidatePoolSize: 10,
};

export const CallInterface: React.FC<CallInterfaceProps> = ({ type, otherUser, incoming, onClose, existingCallId, autoAccept }) => {
  const { user, profile } = useAuth();
  const { t } = useLanguage();
  const [status, setStatus] = useState<'ringing' | 'connecting' | 'active' | 'ended'>(incoming ? 'ringing' : 'connecting');
  const [connectionQuality, setConnectionQuality] = useState<'excellent' | 'good' | 'fair' | 'poor' | 'searching'>('searching');
  const [isMuted, setIsMuted] = useState(false);
  const [isSpeakerOn, setIsSpeakerOn] = useState(type === 'video');
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [isMinimized, setIsMinimized] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(type === 'audio');
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [callId, setCallId] = useState<string | null>(existingCallId || null);
  const [localMicLevel, setLocalMicLevel] = useState(0);
  const [remoteVolume, setRemoteVolume] = useState(1);
  const [micGain, setMicGain] = useState(1);
  const [showVolumeControls, setShowVolumeControls] = useState(false);
  const [duration, setDuration] = useState(0);

  const localVideoRef = useRef<HTMLVideoElement>(null);
  const audioContext = useRef<AudioContext | null>(null);
  const analyserNode = useRef<AnalyserNode | null>(null);
  const animationFrame = useRef<number | null>(null);

  const localStream = useRef<MediaStream | null>(null);
  const screenStream = useRef<MediaStream | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Unified audio setup for both UI visualization and Peer transmission
  const initAudioPipeline = async (stream: MediaStream) => {
    try {
      if (!audioContext.current || audioContext.current.state === 'closed') {
        audioContext.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      
      const ctx = audioContext.current;
      if (ctx.state === 'suspended') {
        await ctx.resume();
      }

      const source = ctx.createMediaStreamSource(stream);
      
      // Gain node for mic sensitivity
      const gNode = ctx.createGain();
      gNode.gain.value = micGain;
      micGainNode.current = gNode;

      // Analyser for UI level visualization
      const anal = ctx.createAnalyser();
      anal.fftSize = 256;
      analyserNode.current = anal;
      
      // Destination for sending to Peer
      const dest = ctx.createMediaStreamDestination();
      micAudioDestination.current = dest;

      // Connect: Source -> Gain -> Analyser -> Destination
      source.connect(gNode);
      gNode.connect(anal);
      anal.connect(dest);

      // Start level visualization
      const dataArr = new Uint8Array(anal.frequencyBinCount);
      const updateLevel = () => {
        if (analyserNode.current) {
          analyserNode.current.getByteFrequencyData(dataArr);
          let sum = 0;
          for (let i = 0; i < dataArr.length; i++) sum += dataArr[i];
          setLocalMicLevel(sum / dataArr.length);
        }
        animationFrame.current = requestAnimationFrame(updateLevel);
      };
      updateLevel();

      return dest.stream.getAudioTracks()[0];
    } catch (err) {
      console.warn("Audio pipeline init failed:", err);
      // Fallback: return original audio track if processing fails
      return stream.getAudioTracks()[0];
    }
  };

  useEffect(() => {
    if (status !== 'active') {
      setLocalMicLevel(0);
      if (animationFrame.current) cancelAnimationFrame(animationFrame.current);
    }
    // No explicit close here to keep the pipeline alive during the call
    return () => {
      if (animationFrame.current) cancelAnimationFrame(animationFrame.current);
    };
  }, [status]);
  useEffect(() => {
    let interval: number | null = null;
    if (status === 'active') {
      interval = window.setInterval(() => {
        setDuration(prev => prev + 1);
      }, 1000);
    } else {
      setDuration(0);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [status]);

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const remoteAudioRef = useRef<HTMLAudioElement>(null);
  const pc = useRef<RTCPeerConnection | null>(null);
  const remoteStream = useRef<MediaStream>(new MediaStream());
  const micGainNode = useRef<GainNode | null>(null);
  const micAudioDestination = useRef<MediaStreamAudioDestinationNode | null>(null);
  
  useEffect(() => {
    if (remoteVideoRef.current) {
      remoteVideoRef.current.volume = remoteVolume;
    }
    if (remoteAudioRef.current) {
      remoteAudioRef.current.volume = remoteVolume;
    }
  }, [remoteVolume, status]);

  useEffect(() => {
    if (micGainNode.current) {
      micGainNode.current.gain.value = isMuted ? 0 : micGain;
    }
  }, [micGain, isMuted]);

  useEffect(() => {
    const routeAudio = async () => {
      if (status !== 'active') return;
      
      try {
        const audioEl = (type === 'video' ? remoteVideoRef.current : remoteAudioRef.current) as HTMLAudioElement;
        if (!audioEl) return;

        console.log("Routing audio. Speaker status:", isSpeakerOn);
        
        if ('setSinkId' in HTMLAudioElement.prototype) {
          const devices = await navigator.mediaDevices.enumerateDevices();
          const outputs = devices.filter(d => d.kind === 'audiooutput');
          
          if (isSpeakerOn) {
            // Find loudspeaker
            const speaker = outputs.find(d => 
              d.label.toLowerCase().includes('speaker') || 
              d.label.toLowerCase().includes('loud') || 
              d.label.toLowerCase().includes('hands-free')
            ) || outputs.find(d => d.deviceId === 'default');

            if (speaker) {
              await audioEl.setSinkId(speaker.deviceId);
              console.log("Audio routed to speaker:", speaker.label);
            }
          } else {
            // Find earpiece
            const earpiece = outputs.find(d => 
              d.label.toLowerCase().includes('earpiece') || 
              d.label.toLowerCase().includes('receiver') || 
              d.label.toLowerCase().includes('handset') || 
              d.label.toLowerCase().includes('phone')
            ) || outputs.find(d => 
              d.kind === 'audiooutput' && 
              !d.label.toLowerCase().includes('speaker') && 
              !d.label.toLowerCase().includes('loud') &&
              d.deviceId !== 'default'
            );

            if (earpiece) {
              await audioEl.setSinkId(earpiece.deviceId);
              console.log("Audio routed to earpiece:", earpiece.label);
            } else {
              // On many browsers, setting to empty string defaults to the primary "communication" device (earpiece)
              // if correctly configured by the OS
              await audioEl.setSinkId("");
              console.log("No explicit earpiece found, reset to default routing");
            }
          }
        } else {
          console.warn("setSinkId not supported in this browser");
        }
      } catch (err) {
        console.warn("Audio routing failed:", err);
      }
    };
    routeAudio();
  }, [isSpeakerOn, status, type]);

  // Lazy init PC
  const getPC = () => {
    if (!pc.current || (pc.current as any).signalingState === 'closed') {
      const peerConnection = new RTCPeerConnection(servers);
      
      peerConnection.onconnectionstatechange = () => {
        console.log("Connection State:", peerConnection.connectionState);
      };

      peerConnection.ontrack = (event) => {
        console.log("Track received:", event.track.kind);
        
        if (event.streams && event.streams[0]) {
          remoteStream.current = event.streams[0];
        } else {
          remoteStream.current.addTrack(event.track);
        }
        
        if (remoteVideoRef.current) {
          remoteVideoRef.current.srcObject = remoteStream.current;
          remoteVideoRef.current.play().catch(e => console.warn("Video play failed:", e));
        }

        if (remoteAudioRef.current) {
          remoteAudioRef.current.srcObject = remoteStream.current;
          remoteAudioRef.current.play().catch(e => console.warn("Audio play failed:", e));
        }

        setStatus('active');
        audioRef.current?.pause();
      };

      pc.current = peerConnection;
    }
    return pc.current;
  };

  useEffect(() => {
    // Sync remote stream to elements
    if (status === 'active' && remoteStream.current) {
      if (remoteVideoRef.current && remoteVideoRef.current.srcObject !== remoteStream.current) {
        remoteVideoRef.current.srcObject = remoteStream.current;
      }
      if (remoteAudioRef.current && remoteAudioRef.current.srcObject !== remoteStream.current) {
        remoteAudioRef.current.srcObject = remoteStream.current;
      }
    }
  }, [status]);

  useEffect(() => {
    console.log("CallInterface mounted", { status, incoming, existingCallId });
    
    // Sound setup
    const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/1359/1359-preview.mp3');
    audio.loop = true;
    audioRef.current = audio;

    if (status === 'ringing' || status === 'connecting') {
      audio.play().catch(e => console.log("Audio autoplay blocked", e));
    }

    if (!incoming) {
      setupCall();
    } else if (existingCallId) {
      if (autoAccept) {
        console.log("Auto-accepting call from notification/deep link");
        acceptCall();
      }

      // Receiver: Listen for caller ending
      const unsubscribe = onSnapshot(doc(db, 'calls', existingCallId), (snap) => {
        const data = snap.data();
        if (snap.exists() && (data?.status === 'ended' || data?.status === 'missed')) {
          setStatus('ended');
          setTimeout(onClose, 1500);
        }
      }, (err) => {
        import('./firebase').then(({ handleFirestoreError, OperationType }) => {
          handleFirestoreError(err, OperationType.GET, `calls/${existingCallId}`);
        }).catch(() => console.error("Incoming call sync error:", err));
      });

      return () => {
        unsubscribe();
        cleanup();
      };
    }

    return () => {
      cleanup();
    };
  }, []);

  useEffect(() => {
    if (status !== 'active' || !pc.current) {
        setConnectionQuality('searching');
        return;
    }

    let lastPacketsLost = 0;
    
    const interval = setInterval(async () => {
      if (!pc.current || pc.current.signalingState === 'closed') return;
      
      try {
        const stats = await pc.current.getStats();
        let currentRTT = 0;
        let currentLoss = 0;

        stats.forEach(report => {
          // Monitor remote-candidate-pair for RTT
          if (report.type === 'remote-inbound-rtp' && report.kind === 'video') {
            currentRTT = report.roundTripTime || 0;
          }
          
          if (report.type === 'inbound-rtp') {
            const lost = report.packetsLost || 0;
            currentLoss = lost - lastPacketsLost;
            lastPacketsLost = lost;
          }
        });

        // Qualitative assessment
        if (currentRTT === 0) setConnectionQuality('good'); // Default
        else if (currentRTT < 0.1 && currentLoss <= 1) setConnectionQuality('excellent');
        else if (currentRTT < 0.2 && currentLoss <= 5) setConnectionQuality('good');
        else if (currentRTT < 0.4 || currentLoss <= 15) setConnectionQuality('fair');
        else setConnectionQuality('poor');

      } catch (err) {
        console.warn("Stats error:", err);
      }
    }, 2000);

    return () => clearInterval(interval);
  }, [status]);

  useEffect(() => {
    if (status === 'active' || status === 'ended') {
      audioRef.current?.pause();
    }
  }, [status]);

  useEffect(() => {
    if (localStream.current) {
      localStream.current.getAudioTracks().forEach(track => {
        track.enabled = !isMuted;
      });
    }
  }, [isMuted]);

  useEffect(() => {
    if (localStream.current) {
      localStream.current.getVideoTracks().forEach(track => {
        track.enabled = !isVideoOff;
      });
    }
  }, [isVideoOff]);

  const cleanup = async () => {
    localStream.current?.getTracks().forEach(t => t.stop());
    screenStream.current?.getTracks().forEach(t => t.stop());
    if (audioContext.current && audioContext.current.state !== 'closed') {
      audioContext.current.close().catch(e => console.warn(e));
    }
    if (pc.current) {
      pc.current.ontrack = null;
      pc.current.onicecandidate = null;
      if (pc.current.signalingState !== 'closed') {
        pc.current.close();
      }
      pc.current = null;
    }
    audioRef.current?.pause();
  };

  const setupCall = async () => {
    if (!user) return;
    setStatus('connecting');

    const peerConnection = getPC();

    // 1. Get User Media
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: type === 'video' ? { facingMode } : false, 
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        } 
      });

      // Check if signaling was closed while waiting for media
      if (!pc.current || pc.current.signalingState === 'closed') {
        stream.getTracks().forEach(t => t.stop());
        return;
      }

      localStream.current = stream;
      if (localVideoRef.current) localVideoRef.current.srcObject = stream;

      const audioTrack = await initAudioPipeline(stream);
      const videoTrack = stream.getVideoTracks()[0];
      
      if (audioTrack && pc.current && pc.current.signalingState !== 'closed') {
        pc.current.addTrack(audioTrack, stream);
      }
      if (videoTrack && pc.current && pc.current.signalingState !== 'closed') {
        pc.current.addTrack(videoTrack, stream);
      }
    } catch (err) {
      console.error("Media initialization error:", err);
      setStatus('ended');
      setTimeout(onClose, 2000);
      return;
    }

    // Check PC again
    const currentPC = getPC();
    console.log("setupCall starting. Signaling state:", currentPC.signalingState);
    if (!currentPC || currentPC.signalingState === 'closed') return;

    // Caller Logic
    const callRef = doc(collection(db, 'calls'));
    setCallId(callRef.id);
    const offerCandidates = collection(callRef, 'offerCandidates');
    const answerCandidates = collection(callRef, 'answerCandidates');

    const offerDescription = await currentPC.createOffer();

    if (currentPC.signalingState === 'closed') return;
    console.log("Calling setLocalDescription (caller). State:", currentPC.signalingState);
    await currentPC.setLocalDescription(offerDescription);
    const localDesc = currentPC.localDescription;
    if (!localDesc) throw new Error("Local description not set");

    const offer = {
      sdp: localDesc.sdp,
      type: localDesc.type,
    };

    await setDoc(callRef, { 
      offer, 
      status: 'ringing', 
      callerId: user.uid, 
      receiverId: otherUser.uid,
      type,
      createdAt: serverTimestamp()
    });

    // NOW start sending ICE candidates AFTER call doc is created
    currentPC.onicecandidate = (event) => {
      if (event.candidate && currentPC.signalingState !== 'closed') {
        addDoc(offerCandidates, event.candidate.toJSON()).catch(e => {
            console.error("Candidate add error", e);
            // Optionally notify user
        });
      }
    };

    // Send Push Notification for background devices
    const receiverSnap = await getDoc(doc(db, 'users', otherUser.uid));
    const receiverData = receiverSnap.data();
    if (receiverData?.pushSubscription) {
      notifyCall(receiverData.pushSubscription, callRef.id, profile?.displayName || 'Loop User');
    }

    // Listen for Answer
    const unsubAnswer = onSnapshot(callRef, (snapshot) => {
      const data = snapshot.data();
      if (!currentPC.currentRemoteDescription && data?.answer && currentPC.signalingState !== 'closed') {
        const answerDescription = new RTCSessionDescription(data.answer);
        currentPC.setRemoteDescription(answerDescription).catch(e => console.error("Set remote fail", e));
        setStatus('active');
        audioRef.current?.pause();
      }
      if (data?.status === 'ended') {
        unsubAnswer();
        setStatus('ended');
        setTimeout(onClose, 1000);
      }
    });

    // Listen for ICE Candidates from receiver
    onSnapshot(answerCandidates, (snapshot) => {
      snapshot.docChanges().forEach((change) => {
        if (change.type === 'added' && currentPC.signalingState !== 'closed') {
          const data = change.doc.data();
          currentPC.addIceCandidate(new RTCIceCandidate(data)).catch(e => console.warn("ICE error", e));
        }
      });
    });
  };

  const endCall = async () => {
    const finalStatus = status === 'ringing' ? 'missed' : 'ended';
    setStatus('ended');
    audioRef.current?.pause();
    if (callId || existingCallId) {
      const id = callId || existingCallId;
      if (id) {
        await updateDoc(doc(db, 'calls', id), { status: finalStatus }).catch(e => console.warn(e));
      }
    }
    setTimeout(onClose, 1000);
  };

  const switchCamera = async () => {
    if (!localStream.current || type !== 'video') return;
    
    const newFacingMode = facingMode === 'user' ? 'environment' : 'user';
    
    try {
      // 1. Explicitly stop and remove old track FIRST to free up hardware
      const oldVideoTrack = localStream.current.getVideoTracks()[0];
      if (oldVideoTrack) {
        oldVideoTrack.stop();
        localStream.current.removeTrack(oldVideoTrack);
      }

      // 2. Request new track
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: newFacingMode },
        audio: false
      });

      const newVideoTrack = stream.getVideoTracks()[0];
      localStream.current.addTrack(newVideoTrack);
      setFacingMode(newFacingMode);

      if (localVideoRef.current) {
        localVideoRef.current.srcObject = localStream.current;
      }

      const peerConnection = getPC();
      const sender = peerConnection.getSenders().find(s => s.track?.kind === 'video');
      if (sender) {
        await sender.replaceTrack(newVideoTrack);
      }
    } catch (err) {
      console.error("Camera switch error:", err);
      // Fallback: try to restore old camera if new one fails?
    }
  };

  const toggleScreenSharing = async () => {
    const peerConnection = getPC();
    if (!peerConnection || status !== 'active') return;

    if (!isScreenSharing) {
      try {
        const stream = await navigator.mediaDevices.getDisplayMedia({ video: true });
        screenStream.current = stream;
        const screenTrack = stream.getVideoTracks()[0];

        const sender = peerConnection.getSenders().find(s => s.track?.kind === 'video');
        if (sender) {
          await sender.replaceTrack(screenTrack);
        }

        if (localVideoRef.current) {
          localVideoRef.current.srcObject = stream;
        }

        setIsScreenSharing(true);
        screenTrack.onended = () => {
          stopScreenSharing();
        };
      } catch (err) {
        console.error("Screen share error:", err);
      }
    } else {
      stopScreenSharing();
    }
  };

  const stopScreenSharing = async () => {
    const peerConnection = getPC();
    if (screenStream.current) {
      screenStream.current.getTracks().forEach(t => t.stop());
      screenStream.current = null;
    }

    if (localStream.current) {
      const cameraTrack = localStream.current.getVideoTracks()[0];
      const sender = peerConnection.getSenders().find(s => s.track?.kind === 'video');
      if (sender && cameraTrack) {
        await sender.replaceTrack(cameraTrack);
      }

      if (localVideoRef.current) {
        localVideoRef.current.srcObject = localStream.current;
      }
    }

    setIsScreenSharing(false);
  };

  const acceptCall = async () => {
    if (!existingCallId || status !== 'ringing') return;
    
    console.log("Accepting call:", existingCallId);
    setStatus('connecting');
    audioRef.current?.pause();

    try {
      const currentPC = getPC();

      // 1. Signaling Handshake - GET OFFER FIRST
      const callRef = doc(db, 'calls', existingCallId);
      const callSnap = await getDoc(callRef);
      const callData = callSnap.data();
      
      if (!callData || !callData.offer) {
        throw new Error("No call offer found");
      }

      // SET REMOTE FIRST to ensure m-line order is established from offer
      if (currentPC.signalingState === 'closed') return;
      console.log("Setting remote description (offer). State:", currentPC.signalingState);
      const offerDesc = new RTCSessionDescription(callData.offer);
      await currentPC.setRemoteDescription(offerDesc);
      console.log("Receiver: Remote description (offer) set");

      // 2. Get media
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: type === 'video' ? { facingMode } : false, 
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        } 
      });

      if (!currentPC || currentPC.signalingState === 'closed') {
        stream.getTracks().forEach(t => t.stop());
        return;
      }

      localStream.current = stream;
      if (localVideoRef.current) localVideoRef.current.srcObject = stream;

      const audioTrack = await initAudioPipeline(stream);
      const videoTrack = stream.getVideoTracks()[0];

      // Add tracks according to the transceivers created by setRemoteDescription
      // This ensures we match the m-line order of the offer
      const transceivers = currentPC.getTransceivers();
      console.log("Transceivers established:", transceivers.length);
      
      // Map tracks to transceivers to maintain SDP order strictly
      let audioReplaced = false;
      let videoReplaced = false;

      for (const transceiver of transceivers) {
        if (transceiver.receiver.track.kind === 'audio' && audioTrack && !audioReplaced) {
          await transceiver.sender.replaceTrack(audioTrack);
          audioReplaced = true;
        } else if (transceiver.receiver.track.kind === 'video' && videoTrack && !videoReplaced) {
          await transceiver.sender.replaceTrack(videoTrack);
          videoReplaced = true;
        }
      }

      // If tracks weren't mapped to transceivers, add them now
      // (This can happen if offer was recvonly or has fewer m-lines than tracks we want to send)
      if (!audioReplaced && audioTrack) currentPC.addTrack(audioTrack, stream);
      if (!videoReplaced && videoTrack) currentPC.addTrack(videoTrack, stream);

      // 3. Setup PC listeners
      currentPC.onicecandidate = (event) => {
        if (event.candidate && currentPC.signalingState !== 'closed') {
          const answerCandidates = collection(doc(db, 'calls', existingCallId), 'answerCandidates');
          addDoc(answerCandidates, event.candidate.toJSON()).catch(e => console.error("Answer cand fail", e));
        }
      };

      // Now listen for candidates AFTER remote description is set
      const offerCandidates = collection(callRef, 'offerCandidates');
      onSnapshot(offerCandidates, (snap) => {
        snap.docChanges().forEach(change => {
          if (change.type === 'added' && currentPC && currentPC.signalingState !== 'closed') {
            const data = change.doc.data();
            currentPC.addIceCandidate(new RTCIceCandidate(data)).catch(e => console.warn("Receiver ICE error:", e));
          }
        });
      });

      // CREATE AND SEND ANSWER
      if (currentPC.signalingState === 'closed') return;
      const answerDescription = await currentPC.createAnswer();
      if (currentPC.signalingState === 'closed') return;
      console.log("Calling setLocalDescription (answer). State:", currentPC.signalingState);
      await currentPC.setLocalDescription(answerDescription);
      const finalAnswerDescription = currentPC.localDescription;
      if (!finalAnswerDescription) throw new Error("Local answer description not set");

      const answer = {
        type: finalAnswerDescription.type,
        sdp: finalAnswerDescription.sdp,
      };

      console.log("Answering call...");
      await updateDoc(callRef, { answer, status: 'active' });
      
    } catch (err) {
      console.error("Failed to accept call:", err);
      endCall();
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ 
        opacity: 1, 
        scale: 1,
        width: isMinimized ? '260px' : '100%',
        height: isMinimized ? '400px' : '100%',
        bottom: isMinimized ? '24px' : '0',
        right: isMinimized ? '24px' : '0',
        top: isMinimized ? 'auto' : '0',
        left: isMinimized ? 'auto' : '0',
      }}
      className={`fixed z-[100] flex items-center justify-center bg-slate-950 transition-all duration-300 ${isMinimized ? 'rounded-2xl border border-white/10 shadow-2xl overflow-hidden' : 'inset-0'}`}
    >
      <div className="relative h-full w-full overflow-hidden bg-slate-950" onClick={async () => {
        if (audioContext.current && audioContext.current.state === 'suspended') {
          await audioContext.current.resume().catch(e => console.warn(e));
        }
      }}>
        {/* Header Controls (Minimize) */}
        {status === 'active' && (
          <div className="absolute top-4 left-4 z-40 flex gap-2">
            <button 
              onClick={() => setIsMinimized(!isMinimized)}
              className="p-2 rounded-full bg-black/40 text-white backdrop-blur-md border border-white/10 hover:bg-black/60 transition-colors"
            >
              {isMinimized ? <Maximize2 className="h-4 w-4" /> : <Minimize2 className="h-4 w-4" />}
            </button>
          </div>
        )}
        {/* Remote Media Container */}
        <div className="absolute inset-0 bg-slate-900">
          <video 
            ref={remoteVideoRef} 
            autoPlay 
            playsInline
            className={`h-full w-full object-cover ${type === 'video' && status === 'active' ? 'block' : 'opacity-0.01 pointer-events-none absolute inset-0'}`}
            style={{ opacity: type === 'video' && status === 'active' ? 1 : 0.001 }}
          />

          <audio 
            ref={remoteAudioRef} 
            autoPlay 
            playsInline
            className="hidden"
          />

          {(type === 'video' && status === 'active') ? (
            <div className="relative h-full w-full">
              {/* Quality Overlay for Video */}
              <div className="absolute left-4 top-4 z-30">
                <div className="flex items-center gap-2 px-3 py-1 bg-black/40 rounded-full backdrop-blur-md border border-white/10">
                  <div className={`h-2 w-2 rounded-full animate-pulse ${
                    connectionQuality === 'excellent' ? 'bg-emerald-400' :
                    connectionQuality === 'good' ? 'bg-blue-400' :
                    connectionQuality === 'fair' ? 'bg-yellow-400' :
                    connectionQuality === 'poor' ? 'bg-red-500' : 'bg-slate-400'
                  }`} />
                  <span className="text-[10px] font-bold uppercase tracking-widest text-white/90">
                    {connectionQuality === 'searching' ? 'Syncing...' : connectionQuality}
                  </span>
                </div>
              </div>
            </div>
          ) : (
            <div className={`flex h-full w-full flex-col items-center justify-center space-y-4 ${isMinimized ? 'scale-75' : ''}`}>
              <div className="relative z-10">
                <img src={otherUser.photoURL || 'https://via.placeholder.com/120'} alt="" className={`${isMinimized ? 'h-20 w-20' : 'h-32 w-32'} rounded-full border-4 border-emerald-500 shadow-xl`} />
                {status === 'active' && (
                   <motion.div 
                    animate={{ scale: [1, 1.3, 1], opacity: [0.3, 0.1, 0.3] }}
                    transition={{ repeat: Infinity, duration: 2 }}
                    className="absolute inset-0 rounded-full bg-emerald-500 -z-10" 
                   />
                )}
              </div>
              <h2 className="text-2xl font-bold text-white">{otherUser.displayName}</h2>
              <div className="flex flex-col items-center gap-1">
                <p className="text-emerald-400 font-medium uppercase tracking-widest text-sm text-center">
                  {status === 'connecting' ? t('connecting') 
                   : status === 'ringing' ? (incoming ? 'Incoming Call...' : t('ringing')) 
                   : status === 'ended' ? t('callEnded')
                   : t('activeCall')}
                </p>
                {status === 'active' && (
                  <div className="flex items-center gap-2 text-white/60 font-mono text-xl">
                    <Clock className="h-4 w-4" />
                    <span>{formatDuration(duration)}</span>
                  </div>
                )}
              </div>
              
              {status === 'active' && (
                <div className="flex flex-col items-center gap-4">
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-2 px-3 py-1 bg-white/10 rounded-full backdrop-blur-sm">
                      <div className={`h-2 w-2 rounded-full animate-pulse ${
                        connectionQuality === 'excellent' ? 'bg-emerald-400' :
                        connectionQuality === 'good' ? 'bg-blue-400' :
                        connectionQuality === 'fair' ? 'bg-yellow-400' :
                        connectionQuality === 'poor' ? 'bg-red-500' : 'bg-slate-400'
                      }`} />
                      <span className="text-[10px] font-bold uppercase tracking-widest text-white/70">
                        {connectionQuality === 'searching' ? 'Checking connection...' : 
                         `${connectionQuality} Signal`}
                      </span>
                    </div>

                    {!isMuted && (
                      <div className="flex gap-1 items-center bg-white/10 px-3 py-1 rounded-full backdrop-blur-sm">
                        <Mic className="h-3 w-3 text-emerald-400" />
                        <div className="flex gap-0.5 items-center h-2">
                          {[1, 2, 3].map((i) => (
                            <motion.div
                              key={i}
                              animate={{ 
                                height: Math.max(2, (localMicLevel / 255) * 12 * (i === 2 ? 1 : 0.6)) 
                              }}
                              className="w-1 bg-emerald-400 rounded-full"
                            />
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Local Video Mini */}
        {type === 'video' && !isMinimized && (
          <div className="absolute right-4 top-4 h-40 w-28 overflow-hidden rounded-xl border-2 border-white/20 bg-slate-900 shadow-xl z-20">
            <video 
                ref={localVideoRef} 
                autoPlay 
                muted 
                playsInline 
                className={`h-full w-full object-cover transition-opacity duration-300 ${isScreenSharing ? '' : 'mirror'} ${(isVideoOff && !isScreenSharing) ? 'opacity-0' : 'opacity-100'}`} 
            />
            {(isVideoOff && !isScreenSharing) && (
              <div className="absolute inset-0 flex items-center justify-center bg-slate-800">
                <img src={profile?.photoURL || null} alt="" className="h-12 w-12 rounded-full border-2 border-slate-700 object-cover" />
              </div>
            )}
          </div>
        )}

        {/* Controls */}
        <div className={`absolute bottom-8 left-0 right-0 px-4 flex flex-col items-center z-30 transition-all ${isMinimized ? 'scale-90 pb-0' : 'pb-4'}`}>
            <AnimatePresence>
                {showVolumeControls && !isMinimized && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    className="absolute bottom-24 bg-slate-900/90 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-2xl w-72 space-y-5"
                  >
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 text-white/70 text-[10px] font-bold uppercase tracking-widest">
                          <Volume2 className="h-3.5 w-3.5" />
                          <span>Incoming Volume</span>
                        </div>
                        <span className="text-emerald-400 font-mono text-xs">{Math.round(remoteVolume * 100)}%</span>
                      </div>
                      <input 
                        type="range" 
                        min="0" max="1" 
                        step="0.01" 
                        value={remoteVolume} 
                        onChange={(e) => setRemoteVolume(parseFloat(e.target.value))}
                        className="w-full h-1.5 bg-white/5 rounded-full appearance-none cursor-pointer accent-emerald-500"
                      />
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 text-white/70 text-[10px] font-bold uppercase tracking-widest">
                          <Mic className="h-3.5 w-3.5" />
                          <span>Mic Sensitivity</span>
                        </div>
                        <span className="text-blue-400 font-mono text-xs">{Math.round(micGain * 100)}%</span>
                      </div>
                      <input 
                        type="range" 
                        min="0" max="2" 
                        step="0.01" 
                        value={micGain} 
                        onChange={(e) => setMicGain(parseFloat(e.target.value))}
                        className="w-full h-1.5 bg-white/5 rounded-full appearance-none cursor-pointer accent-blue-500"
                      />
                    </div>

                    <div className="pt-2 border-t border-white/5">
                      <button 
                        onClick={() => setShowVolumeControls(false)}
                        className="w-full py-2 text-center text-white/40 hover:text-white transition-colors text-[10px] font-bold uppercase tracking-widest"
                      >
                        Close Settings
                      </button>
                    </div>
                  </motion.div>
                )}

                {status === 'ringing' && incoming ? (
                  <motion.div 
                    initial={{ y: 50, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    className="flex flex-col items-center gap-8"
                  >
                    <div className="flex gap-12 sm:gap-20">
                      <div className="flex flex-col items-center gap-3">
                        <button 
                          onClick={endCall} 
                          className="p-7 rounded-full bg-red-500 text-white shadow-2xl hover:bg-red-600 transition-all active:scale-95"
                          title="Decline"
                        >
                          <PhoneOff className="h-9 w-9" />
                        </button>
                        <span className="text-white/60 text-xs font-bold uppercase tracking-widest">Decline</span>
                      </div>

                      <div className="flex flex-col items-center gap-3">
                        <button 
                          onClick={acceptCall} 
                          className="p-7 rounded-full bg-emerald-500 text-white shadow-2xl hover:bg-emerald-600 transition-all active:scale-95 animate-pulse"
                          title="Answer"
                        >
                          <Phone className="h-9 w-9" />
                        </button>
                        <span className="text-emerald-400 text-xs font-bold uppercase tracking-widest animate-pulse">Accept</span>
                      </div>
                    </div>
                  </motion.div>
                ) : (
                  <div className={`flex items-center transition-all ${isMinimized ? 'gap-2' : 'gap-4'}`}>
                    <button 
                      onClick={() => setIsMuted(!isMuted)}
                      className={`p-3 rounded-full transition-all ${isMuted ? 'bg-white text-slate-900' : 'bg-slate-700/50 text-white backdrop-blur'}`}
                    >
                      {isMuted ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
                    </button>

                    <div className="flex flex-col items-center gap-1">
                      <button 
                        onClick={() => setIsSpeakerOn(!isSpeakerOn)}
                        className={`p-3 rounded-full transition-all ${!isSpeakerOn ? 'bg-white text-slate-900 border-2 border-slate-200' : 'bg-slate-700/50 text-white backdrop-blur'}`}
                        title={t('speaker')}
                      >
                        {isSpeakerOn ? <Volume2 className="h-5 w-5" /> : <Volume1 className="h-5 w-5" />}
                      </button>
                      <span className="text-[10px] text-white/40 font-bold uppercase">{t('speaker')}</span>
                    </div>

                    {type === 'video' && status === 'active' && !isMinimized && (
                      <button 
                        onClick={switchCamera}
                        className="p-3 rounded-full bg-slate-700/50 text-white backdrop-blur hover:bg-slate-700/70 transition-all"
                        title="Switch Camera"
                      >
                        <RefreshCw className="h-5 w-5" />
                      </button>
                    )}
                    
                    <button 
                      onClick={() => setShowVolumeControls(!showVolumeControls)}
                      className={`p-3 rounded-full transition-all ${showVolumeControls ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/20' : 'bg-slate-700/50 text-white backdrop-blur hover:bg-slate-700/70'}`}
                      title="Audio Settings"
                    >
                      <Settings className="h-5 w-5" />
                    </button>

                    <button 
                      onClick={endCall}
                      className={`rounded-full bg-red-500 text-white shadow-lg hover:bg-red-600 transition-colors ${isMinimized ? 'p-3' : 'p-4'}`}
                    >
                      <PhoneOff className={isMinimized ? 'h-6 w-6' : 'h-8 w-8'} />
                    </button>
      
                    {type === 'video' && status === 'active' && !isMinimized && (
                      <button 
                        onClick={toggleScreenSharing}
                        className={`p-3 rounded-full transition-all ${isScreenSharing ? 'bg-blue-500 text-white' : 'bg-slate-700/50 text-white backdrop-blur'}`}
                        title="Share Screen"
                      >
                        <Monitor className="h-5 w-5" />
                      </button>
                    )}

                    {type === 'video' && (
                        <button 
                            onClick={() => setIsVideoOff(!isVideoOff)}
                            className={`p-3 rounded-full transition-all ${isVideoOff ? 'bg-white text-slate-900' : 'bg-slate-700/50 text-white backdrop-blur'}`}
                        >
                            {isVideoOff ? <VideoOff className="h-5 w-5" /> : <Video className="h-5 w-5" />}
                        </button>
                    )}
                  </div>
                )}
            </AnimatePresence>
        </div>

        {/* Ending Overlay */}
        <AnimatePresence>
          {status === 'ended' && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-slate-950/80 backdrop-blur-md text-white"
            >
              <h3 className="text-2xl font-bold">{t('callEnded')}</h3>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
};

