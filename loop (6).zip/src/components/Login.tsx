import React, { useState, useEffect } from 'react';
import { signIn, auth } from './firebase';
import { LogIn, Phone, ArrowLeft, Loader2, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { RecaptchaVerifier, signInWithPhoneNumber, ConfirmationResult } from 'firebase/auth';

export const Login: React.FC = () => {
  const [loginMethod, setLoginMethod] = useState<'google' | 'phone' | null>(null);
  const [countryCode, setCountryCode] = useState('+880');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [otp, setOtp] = useState('');
  const [step, setStep] = useState<'phone' | 'otp'>('phone');
  const [confirmationResult, setConfirmationResult] = useState<ConfirmationResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const countries = [
    { code: '+880', name: 'Bangladesh', flag: '🇧🇩' },
    { code: '+91', name: 'India', flag: '🇮🇳' },
    { code: '+92', name: 'Pakistan', flag: '🇵🇰' },
    { code: '+971', name: 'UAE', flag: '🇦🇪' },
    { code: '+966', name: 'Saudi Arabia', flag: '🇸🇦' },
    { code: '+60', name: 'Malaysia', flag: '🇲🇾' },
    { code: '+65', name: 'Singapore', flag: '🇸🇬' },
    { code: '+1', name: 'USA/Canada', flag: '🇺🇸' },
    { code: '+44', name: 'UK', flag: '🇬🇧' },
    { code: '+61', name: 'Australia', flag: '🇦🇺' },
    { code: '+49', name: 'Germany', flag: '🇩🇪' },
    { code: '+33', name: 'France', flag: '🇫🇷' },
    { code: '+81', name: 'Japan', flag: '🇯🇵' },
    { code: '+82', name: 'South Korea', flag: '🇰🇷' },
    { code: '+86', name: 'China', flag: '🇨🇳' },
    { code: '+39', name: 'Italy', flag: '🇮🇹' },
    { code: '+34', name: 'Spain', flag: '🇪🇸' },
    { code: '+7', name: 'Russia', flag: '🇷🇺' },
    { code: '+20', name: 'Egypt', flag: '🇪🇬' },
    { code: '+234', name: 'Nigeria', flag: '🇳🇬' },
    { code: '+27', name: 'South Africa', flag: '🇿🇦' },
    { code: '+55', name: 'Brazil', flag: '🇧🇷' },
    { code: '+52', name: 'Mexico', flag: '🇲🇽' },
    { code: '+94', name: 'Sri Lanka', flag: '🇱🇰' },
    { code: '+977', name: 'Nepal', flag: '🇳🇵' },
    { code: '+93', name: 'Afghanistan', flag: '🇦🇫' },
    { code: '+62', name: 'Indonesia', flag: '🇮🇩' },
    { code: '+63', name: 'Philippines', flag: '🇵🇭' },
    { code: '+66', name: 'Thailand', flag: '🇹🇭' },
    { code: '+84', name: 'Vietnam', flag: '🇻🇳' },
    { code: '+90', name: 'Turkey', flag: '🇹🇷' },
    { code: '+98', name: 'Iran', flag: '🇮🇷' },
    { code: '+964', name: 'Iraq', flag: '🇮🇶' },
    { code: '+972', name: 'Israel', flag: '🇮🇱' },
    { code: '+965', name: 'Kuwait', flag: '🇰🇼' },
    { code: '+968', name: 'Oman', flag: '🇴🇲' },
    { code: '+974', name: 'Qatar', flag: '🇶🇦' },
  ];

  useEffect(() => {
    if (loginMethod === 'phone' && !window.recaptchaVerifier) {
      window.recaptchaVerifier = new RecaptchaVerifier(auth, 'recaptcha-container', {
        size: 'invisible',
        callback: () => {
          console.log('Recaptcha resolved');
        }
      });
    }
  }, [loginMethod]);

  const handlePhoneSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (!window.recaptchaVerifier) {
        throw new Error('Recaptcha not initialized');
      }

      // Format phone number
      const cleanNumber = phoneNumber.trim().replace(/^0+/, '');
      const formattedPhone = countryCode + cleanNumber;

      const result = await signInWithPhoneNumber(auth, formattedPhone, window.recaptchaVerifier);
      setConfirmationResult(result);
      setStep('otp');
    } catch (err: any) {
      console.error(err);
      if (err.code === 'auth/operation-not-allowed') {
        setError('Phone sign-in is not enabled in your Firebase Console. Please go to Authentication > Sign-in method and enable Phone.');
      } else {
        setError(err.message || 'Failed to send OTP. Check phone number format.');
      }
      if (window.recaptchaVerifier) {
        window.recaptchaVerifier.clear();
        window.recaptchaVerifier = null;
      }
    } finally {
      setLoading(false);
    }
  };

  const handleOtpSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (!confirmationResult) throw new Error('No confirmation result');
      await confirmationResult.confirm(otp);
      // Auth state listener in AuthContext will handle the rest
    } catch (err: any) {
      console.error(err);
      setError('Invalid OTP code. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setError('');
    setLoading(true);
    try {
      await signIn();
    } catch (err: any) {
      console.error("Login error:", err);
      if (err.code === 'auth/popup-blocked') {
        setError('Popup blocked by browser. Please allow popups for this site or try logging in with Phone Number.');
      } else if (err.code === 'auth/operation-not-allowed') {
        setError('Google sign-in is not enabled in your Firebase Console. Please go to Authentication > Sign-in method and enable Google.');
      } else if (err.code === 'auth/cancelled-popup-request' || err.code === 'auth/popup-closed-by-user') {
        // Just reset loading, no need for error message usually
      } else {
        setError(err.message || 'Failed to login with Google.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex h-screen w-full flex-col items-center justify-center bg-brand-gradient p-4 overflow-y-auto">
      <div id="recaptcha-container"></div>
      
      <div className="w-full max-w-md rounded-3xl bg-white/10 backdrop-blur-xl p-8 border border-white/20 shadow-2xl">
        <div className="text-center mb-8">
          <div className="mx-auto mb-6 flex h-24 w-24 items-center justify-center rounded-full bg-gradient-to-br from-indigo-600 to-violet-600 shadow-2xl relative overflow-hidden">
            <div className="absolute inset-0 rounded-full bg-indigo-500/20 animate-ping"></div>
            <svg className="h-12 w-12 text-white relative z-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
          </div>
          <h1 className="text-4xl font-black tracking-tighter text-white uppercase italic">
            LO<span className="text-indigo-400">OP</span>
          </h1>
          <p className="mt-2 text-indigo-100 opacity-80 font-bold uppercase tracking-widest text-[10px]">Infinite Connections | Real Conversations</p>
        </div>

        <AnimatePresence mode="wait">
          {!loginMethod ? (
            <div className="space-y-4">
              <button
                onClick={handleGoogleLogin}
                disabled={loading}
                className="flex w-full items-center justify-center gap-3 rounded-2xl bg-white px-6 py-4 font-bold text-indigo-900 transition-all hover:scale-[1.02] active:scale-95 shadow-lg disabled:opacity-50"
              >
                {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : <img src="https://www.google.com/favicon.ico" alt="Google" className="h-5 w-5" />}
                {loading ? 'Connecting...' : 'Login with Google'}
              </button>

              <button
                onClick={() => setLoginMethod('phone')}
                disabled={loading}
                className="flex w-full items-center justify-center gap-3 rounded-2xl bg-indigo-600 px-6 py-4 font-bold text-white transition-all hover:scale-[1.02] active:scale-95 shadow-lg border border-indigo-400/30 disabled:opacity-50"
              >
                <Phone className="h-5 w-5" />
                Login with Phone Number
              </button>

              {error && <div className="text-red-400 text-xs font-bold bg-red-400/10 p-3 rounded-xl border border-red-400/20 text-center">{error}</div>}
            </div>
          ) : loginMethod === 'phone' ? (
            <div className="space-y-6">
              <button 
                onClick={() => {
                  setLoginMethod(null);
                  setStep('phone');
                  setError('');
                }}
                className="flex items-center gap-2 text-indigo-100 text-sm font-semibold hover:text-white transition-colors"
              >
                <ArrowLeft className="h-4 w-4" />
                Back to options
              </button>

              {step === 'phone' ? (
                <form onSubmit={handlePhoneSubmit} className="space-y-4 text-left">
                  <div>
                    <label className="block text-sm font-bold text-indigo-100 mb-2 uppercase tracking-wider">Phone Number</label>
                    <div className="flex gap-2">
                      <div className="relative w-32 shrink-0">
                        <select
                          value={countryCode}
                          onChange={(e) => setCountryCode(e.target.value)}
                          className="w-full bg-white/10 border border-white/20 rounded-2xl py-4 pl-3 pr-8 text-white text-sm outline-none focus:border-indigo-400 transition-all appearance-none cursor-pointer"
                        >
                          {countries.map(c => (
                            <option key={c.code} value={c.code} className="bg-slate-900 text-white">
                              {c.flag} {c.code}
                            </option>
                          ))}
                        </select>
                        <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none">
                          <svg className="h-4 w-4 text-indigo-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                          </svg>
                        </div>
                      </div>
                      <div className="relative flex-grow">
                        <Phone className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-indigo-300" />
                        <input
                          type="tel"
                          value={phoneNumber}
                          onChange={(e) => setPhoneNumber(e.target.value)}
                          placeholder="Number"
                          className="w-full bg-white/10 border border-white/20 rounded-2xl py-4 pl-12 pr-4 text-white placeholder:text-indigo-300 outline-none focus:border-indigo-400 transition-all"
                          required
                        />
                      </div>
                    </div>
                    <p className="mt-2 text-[10px] text-indigo-300">Format: Select country and enter number (without leading 0)</p>
                  </div>

                  {error && <div className="text-red-400 text-xs font-bold bg-red-400/10 p-3 rounded-xl border border-red-400/20">{error}</div>}

                  <button
                    type="submit"
                    disabled={loading || !phoneNumber}
                    className="w-full bg-emerald-500 hover:bg-emerald-400 disabled:bg-emerald-500/50 disabled:cursor-not-allowed text-white font-bold py-4 rounded-2xl transition-all shadow-lg flex items-center justify-center gap-2"
                  >
                    {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : 'Send OTP Code'}
                  </button>
                </form>
              ) : (
                <form onSubmit={handleOtpSubmit} className="space-y-4 text-left">
                  <div>
                    <label className="block text-sm font-bold text-indigo-100 mb-2 uppercase tracking-wider">Verify Code</label>
                    <div className="relative">
                      <CheckCircle2 className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-indigo-300" />
                      <input
                        type="text"
                        value={otp}
                        onChange={(e) => setOtp(e.target.value)}
                        placeholder="Enter 6-digit code"
                        className="w-full bg-white/10 border border-white/20 rounded-2xl py-4 pl-12 pr-4 text-white placeholder:text-indigo-300 outline-none focus:border-indigo-400 tracking-[0.5em] text-center text-xl font-black transition-all"
                        required
                        maxLength={6}
                      />
                    </div>
                    <button 
                      type="button" 
                      onClick={() => setStep('phone')}
                      className="mt-2 text-[10px] text-indigo-300 hover:text-white font-bold uppercase underline underline-offset-4"
                    >
                      Resend code or change number
                    </button>
                  </div>

                  {error && <div className="text-red-400 text-xs font-bold bg-red-400/10 p-3 rounded-xl border border-red-400/20">{error}</div>}

                  <button
                    type="submit"
                    disabled={loading || otp.length < 6}
                    className="w-full bg-emerald-500 hover:bg-emerald-400 disabled:bg-emerald-500/50 disabled:cursor-not-allowed text-white font-bold py-4 rounded-2xl transition-all shadow-lg flex items-center justify-center gap-2"
                  >
                    {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : 'Verify & Login'}
                  </button>
                </form>
              )}
            </div>
          ) : null}
        </AnimatePresence>

        <p className="mt-10 text-[10px] text-indigo-300 uppercase tracking-[0.3em] font-bold text-center">
          Secure Connection Guaranteed
        </p>
      </div>
    </div>
  );
};

declare global {
  interface Window {
    recaptchaVerifier: RecaptchaVerifier | null;
  }
}
