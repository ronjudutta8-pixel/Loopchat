import React, { useEffect, useState, useRef } from 'react';
import { collection, query, orderBy, onSnapshot, addDoc, serverTimestamp, doc, updateDoc, writeBatch, arrayUnion, setDoc } from 'firebase/firestore';
import { db } from './firebase';
import { useAuth } from './AuthContext';
import { ChatThread, Message, UserProfile } from '../types';
import { Send, Phone, Video, ArrowLeft, MoreVertical, Smile, Paperclip, Mic, Trash2, ShieldAlert, X, Image as ImageIcon, Film, Play, Pause, Users, Ban, Unlock, UserPlus, ShieldCheck, Edit3, Camera, Languages, Check, Download } from 'lucide-react';
import { format } from 'date-fns';
import { CallInterface } from './CallInterface';
import EmojiPicker, { Theme } from 'emoji-picker-react';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage, LANGUAGES } from './LanguageContext';
import { translateText } from '../services/translationService';

interface ChatAreaProps {
  chat: ChatThread;
  onBack: () => void;
}

export const ChatArea: React.FC<ChatAreaProps> = ({ chat, onBack }) => {
  const { user, profile } = useAuth();
  const { language, t } = useLanguage();
  const [messages, setMessages] = useState<Message[]>([]);
  const [translations, setTranslations] = useState<Record<string, string>>({});
  const [isTranslating, setIsTranslating] = useState<string | null>(null);
  const [selectionMode, setSelectionMode] = useState(false);
  const [selectedMessageIds, setSelectedMessageIds] = useState<Set<string>>(new Set());
  const [inputText, setInputText] = useState('');
  const [activeCall, setActiveCall] = useState<{ type: 'audio' | 'video', incoming: boolean, callId?: string } | null>(null);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [showGroupInfo, setShowGroupInfo] = useState(false);
  const [editingName, setEditingName] = useState(false);
  const [newGroupName, setNewGroupName] = useState(chat.groupName || '');
  const [showOptionsId, setShowOptionsId] = useState<string | null>(null);
  const [showHeaderMenu, setShowHeaderMenu] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [typingUsers, setTypingUsers] = useState<string[]>([]);
  const typingTimeoutRef = useRef<number | null>(null);
  const [recordingTime, setRecordingTime] = useState(0);
  const mediaRecorder = useRef<MediaRecorder | null>(null);
  const audioChunks = useRef<Blob[]>([]);
  const recordingInterval = useRef<number | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [fullScreenImage, setFullScreenImage] = useState<string | null>(null);

  const downloadFile = (url: string, filename: string) => {
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecorder.current = new MediaRecorder(stream);
      audioChunks.current = [];

      mediaRecorder.current.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunks.current.push(e.data);
      };

      mediaRecorder.current.onstop = async () => {
        const audioBlob = new Blob(audioChunks.current, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.readAsDataURL(audioBlob);
        reader.onloadend = async () => {
          const base64Audio = reader.result as string;
          await sendFileMessage(base64Audio, 'audio', recordingTime);
        };
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.current.start();
      setIsRecording(true);
      setRecordingTime(0);
      recordingInterval.current = window.setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
    } catch (err) {
      console.error("Error starting recording:", err);
    }
  };

  const stopRecording = () => {
    if (mediaRecorder.current && isRecording) {
      mediaRecorder.current.stop();
      setIsRecording(false);
      if (recordingInterval.current) clearInterval(recordingInterval.current);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64 = reader.result as string;
      const type = file.type.startsWith('image/') ? 'image' : file.type.startsWith('video/') ? 'video' : 'text';
      await sendFileMessage(base64, type as any);
    };
    reader.readAsDataURL(file);
  };

  const sendFileMessage = async (fileData: string, type: 'image' | 'video' | 'audio', duration?: number) => {
    if (!user || !chat.id) return;

    try {
      const msgsRef = collection(db, 'chats', chat.id, 'messages');
      const chatRef = doc(db, 'chats', chat.id);
      
      const newMsg: any = {
        senderId: user.uid,
        senderName: profile?.displayName || 'User',
        text: type === 'audio' ? '🎤 Voice message' : type === 'image' ? '📷 Photo' : '🎥 Video',
        fileUrl: fileData,
        timestamp: serverTimestamp(),
        type: type,
        readBy: [user.uid]
      };

      if (duration !== undefined) {
        newMsg.duration = duration;
      }

      await addDoc(msgsRef, newMsg);

      await updateDoc(chatRef, {
        lastMessage: {
          text: newMsg.text,
          timestamp: Date.now(),
          senderId: user.uid,
          senderName: profile?.displayName || 'Me'
        },
        updatedAt: serverTimestamp()
      });
    } catch (err) {
      import('./firebase').then(({ handleFirestoreError, OperationType }) => {
        handleFirestoreError(err, OperationType.WRITE, `chats/${chat.id}/messages`);
      });
    }
  };

  const onEmojiClick = (emojiObject: any) => {
    setInputText(prev => prev + emojiObject.emoji);
    setShowEmojiPicker(false);
  };

  const otherUserId = !chat.isGroup ? chat.participants.find(p => p !== user?.uid) : null;
  const otherUser = otherUserId ? chat.participantDetails?.[otherUserId] : null;

  const isBlocked = profile?.blockedUsers?.includes(otherUserId || '');
  const amIBlocked = otherUser?.blockedUsers?.includes(user?.uid || '');

  const toggleBlock = async () => {
    if (!user || !otherUserId) return;
    const isCurrentlyBlocked = profile?.blockedUsers?.includes(otherUserId);
    try {
      await updateDoc(doc(db, 'users', user.uid), {
        blockedUsers: isCurrentlyBlocked 
          ? profile?.blockedUsers?.filter(id => id !== otherUserId) || []
          : arrayUnion(otherUserId)
      });
      setShowHeaderMenu(false);
    } catch (err) {
      console.error("Block error:", err);
    }
  };

  useEffect(() => {
    if (!chat.id) return;

    const msgsRef = collection(db, 'chats', chat.id, 'messages');
    // Remove orderBy to avoid index requirement for now
    const q = query(msgsRef);

    const unsubscribe = onSnapshot(q, (snap) => {
      const msgs = snap.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          timestamp: data.timestamp?.toMillis ? data.timestamp.toMillis() : data.timestamp
        } as Message;
      });
      // Sort locally
      msgs.sort((a, b) => (Number(a.timestamp) || 0) - (Number(b.timestamp) || 0));
      setMessages(msgs);
      setTimeout(() => {
        scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
      }, 100);
    }, (error) => {
      import('./firebase').then(({ handleFirestoreError, OperationType }) => {
        handleFirestoreError(error, OperationType.LIST, `chats/${chat.id}/messages`);
      });
    });

    return unsubscribe;
  }, [chat.id]);

  useEffect(() => {
    if (!chat.id || !user || messages.length === 0) return;

    const unreadMessages = messages.filter(m => 
      m.senderId !== user.uid && 
      (!m.readBy || !m.readBy.includes(user.uid))
    );

    if (unreadMessages.length > 0) {
      const batch = writeBatch(db);
      unreadMessages.forEach(m => {
        const msgRef = doc(db, 'chats', chat.id, 'messages', m.id);
        batch.update(msgRef, {
          readBy: arrayUnion(user.uid)
        });
      });
      batch.commit().catch(err => console.error("Error marking messages as read:", err));
    }
  }, [chat.id, user, messages]);

  useEffect(() => {
    if (!chat.id || !user) return;

    const typingRef = collection(db, 'chats', chat.id, 'typing');
    const q = query(typingRef);

    const unsubscribe = onSnapshot(q, (snap) => {
      const typing = snap.docs
        .map(doc => ({ id: doc.id, ...doc.data() } as any))
        .filter(t => t.isTyping && t.id !== user.uid && (Date.now() - (t.lastUpdated || 0) < 10000))
        .map(t => t.displayName || 'Someone');
      
      setTypingUsers([...new Set(typing)]);
    });

    return () => {
      unsubscribe();
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
      updateTypingStatus(false);
    };
  }, [chat.id, user?.uid]);

  const updateTypingStatus = async (isTyping: boolean) => {
    if (!user || !chat.id) return;
    try {
      const typingDocRef = doc(db, 'chats', chat.id, 'typing', user.uid);
      await setDoc(typingDocRef, {
        isTyping,
        displayName: profile?.displayName || 'User',
        lastUpdated: Date.now()
      }, { merge: true });
    } catch (err) {
      console.error("Error updating typing status:", err);
    }
  };

  const updateGroupMetadata = async (updates: Partial<ChatThread>) => {
    if (!user || !chat.id || !chat.isGroup) return;
    const isAdmin = chat.admins?.includes(user.uid) || chat.createdBy === user.uid;
    if (!isAdmin) {
      alert("শুধুমাত্র এডমিনরা এই পরিবর্তন করতে পারবেন");
      return;
    }
    try {
      await updateDoc(doc(db, 'chats', chat.id), {
        ...updates,
        updatedAt: serverTimestamp()
      });
    } catch (err) {
      console.error("Error updating group info:", err);
      alert("পরিবর্তন সেভ করা যায়নি");
    }
  };

  const promoteToAdmin = async (targetId: string) => {
    if (!user || !chat.id || !chat.isGroup) return;
    const currentAdmins = chat.admins || [chat.createdBy || ''];
    if (!currentAdmins.includes(user.uid)) return;
    
    if (currentAdmins.includes(targetId)) return;
    
    await updateGroupMetadata({
      admins: [...currentAdmins, targetId]
    });
  };

  const handleGroupPhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64 = reader.result as string;
      await updateGroupMetadata({ groupPhotoURL: base64 });
    };
    reader.readAsDataURL(file);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputText(e.target.value);
    
    if (!user || !chat.id) return;

    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    } else {
      updateTypingStatus(true);
    }

    typingTimeoutRef.current = window.setTimeout(() => {
      updateTypingStatus(false);
      typingTimeoutRef.current = null;
    }, 3000);
  };

  const handleTranslate = async (msgId: string, text: string) => {
    if (translations[msgId]) {
      // Toggle off if already translated
      const newTranslations = { ...translations };
      delete newTranslations[msgId];
      setTranslations(newTranslations);
      setShowOptionsId(null);
      return;
    }

    setIsTranslating(msgId);
    setShowOptionsId(null);
    
    try {
      const targetLangName = LANGUAGES.find(l => l.code === language)?.name || language;
      const translated = await translateText(text, targetLangName);
      setTranslations(prev => ({ ...prev, [msgId]: translated }));
    } catch (err) {
      console.error("Translation failed:", err);
    } finally {
      setIsTranslating(null);
    }
  };

  const toggleMessageSelection = (id: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    const newSelected = new Set(selectedMessageIds);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedMessageIds(newSelected);
    if (newSelected.size === 0) setSelectionMode(false);
  };

  const deleteSelectedMessages = async () => {
    if (selectedMessageIds.size === 0 || !chat.id) return;
    const confirmMsg = `${selectedMessageIds.size}টি মেসেজ ডিলিট করতে চান?`;
    if (!window.confirm(confirmMsg)) return;

    try {
      const batch = writeBatch(db);
      selectedMessageIds.forEach(id => {
        const msgRef = doc(db, 'chats', chat.id!, 'messages', id);
        batch.update(msgRef, {
          deletedFor: arrayUnion(user?.uid)
        });
      });
      await batch.commit();
      setSelectedMessageIds(new Set());
      setSelectionMode(false);
    } catch (err: any) {
      console.error("Error deleting messages:", err);
      const { handleFirestoreError, OperationType } = await import('./firebase');
      try {
        handleFirestoreError(err, OperationType.UPDATE, `chats/${chat.id}/messages`);
      } catch (structuredErr: any) {
        alert("মেসেজ ডিলিট করা যায়নি: " + structuredErr.message);
      }
    }
  };

  const sendMessage = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!inputText.trim() || !user || !chat.id) return;

    const text = inputText.trim();
    setInputText('');
    
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
      typingTimeoutRef.current = null;
    }
    updateTypingStatus(false);

    try {
      const msgsRef = collection(db, 'chats', chat.id, 'messages');
      const chatRef = doc(db, 'chats', chat.id);
      
      const newMsg = {
        senderId: user.uid,
        senderName: profile?.displayName || 'User',
        text: text,
        timestamp: serverTimestamp(),
        type: 'text',
        readBy: [user.uid]
      };

      await addDoc(msgsRef, newMsg);

      await updateDoc(chatRef, {
        lastMessage: {
          text: text,
          timestamp: Date.now(),
          senderId: user.uid,
          senderName: profile?.displayName || 'Me'
        },
        updatedAt: serverTimestamp()
      });
    } catch (err) {
      import('./firebase').then(({ handleFirestoreError, OperationType }) => {
        handleFirestoreError(err, OperationType.WRITE, `chats/${chat.id}/messages`);
      });
    }
  };

  const startCall = (type: 'audio' | 'video') => {
    if (chat.isGroup) {
      alert("গ্রুপ কল এখনো চালু হয়নি");
      return;
    }
    setActiveCall({ type, incoming: false });
  };

  const deleteForMe = async (messageId: string) => {
    if (!chat.id || !user) return;
    try {
      const msgRef = doc(db, 'chats', chat.id, 'messages', messageId);
      await updateDoc(msgRef, {
        deletedFor: arrayUnion(user.uid)
      });
      setShowOptionsId(null);
    } catch (err: any) {
      console.error("Delete for me error:", err);
      const { handleFirestoreError, OperationType } = await import('./firebase');
      try {
        handleFirestoreError(err, OperationType.UPDATE, `chats/${chat.id}/messages/${messageId}`);
      } catch (structuredErr: any) {
        alert("মেসেজ ডিলিট করা যায়নি: " + structuredErr.message);
      }
    }
  };

  const deleteForEveryone = async (messageId: string) => {
    if (!chat.id || !user) return;
    try {
      const msgRef = doc(db, 'chats', chat.id, 'messages', messageId);
      const chatRef = doc(db, 'chats', chat.id);
      
      await updateDoc(msgRef, {
        isDeletedForEveryone: true,
        text: '🚫 This message was deleted'
      });

      // Update chat last message if this was it
      if (chat.lastMessage?.timestamp === messages.find(m => m.id === messageId)?.timestamp) {
        await updateDoc(chatRef, {
          'lastMessage.text': '🚫 This message was deleted'
        });
      }

      setShowOptionsId(null);
    } catch (err: any) {
      console.error("Delete for everyone error:", err);
      const { handleFirestoreError, OperationType } = await import('./firebase');
      try {
        handleFirestoreError(err, OperationType.UPDATE, `chats/${chat.id}/messages/${messageId}`);
      } catch (structuredErr: any) {
        alert("মেসেজ ডিলিট করা যায়নি: " + structuredErr.message);
      }
    }
  };

  const clearChat = async () => {
    if (!chat.id || !user || messages.length === 0) return;
    if (!window.confirm("আপনি কি নিশ্চিত যে আপনি পুরো চ্যাট ক্লিয়ার করতে চান?")) return;

    try {
      const batch = writeBatch(db);
      messages.forEach(msg => {
        if (!msg.deletedFor?.includes(user.uid)) {
          const msgRef = doc(db, 'chats', chat.id!, 'messages', msg.id);
          batch.update(msgRef, {
            deletedFor: arrayUnion(user.uid)
          });
        }
      });
      await batch.commit();
      setShowHeaderMenu(false);
    } catch (err: any) {
      console.error("Clear chat error:", err);
      const { handleFirestoreError, OperationType } = await import('./firebase');
      try {
        handleFirestoreError(err, OperationType.UPDATE, `chats/${chat.id}/messages`);
      } catch (structuredErr: any) {
        alert("চ্যাট ক্লিয়ার করা যায়নি: " + structuredErr.message);
      }
    }
  };

  const filteredMessages = messages.filter(msg => {
    if (msg.deletedFor && user && msg.deletedFor.includes(user.uid)) return false;
    return true;
  });

  return (
    <div className="flex flex-col h-full bg-[#f0f2f5]">
      {/* Header */}
      <div className="flex items-center justify-between bg-white px-4 py-3 border-b border-slate-200 z-10 sticky top-0 shadow-sm">
        <div 
          className="flex items-center gap-3 cursor-pointer hover:bg-slate-50 transition-colors rounded-lg flex-grow min-w-0 pr-2"
          onClick={() => chat.isGroup && setShowGroupInfo(true)}
        >
          <button onClick={(e) => { e.stopPropagation(); onBack(); }} className="md:hidden p-1 hover:bg-slate-100 rounded-full shrink-0">
            <ArrowLeft className="h-6 w-6 text-slate-600" />
          </button>
          <div className="relative shrink-0">
            {chat.isGroup ? (
              <div className="h-10 w-10 rounded-full overflow-hidden border border-emerald-200">
                {chat.groupPhotoURL ? (
                  <img src={chat.groupPhotoURL} alt="" className="h-full w-full object-cover" />
                ) : (
                  <div className="h-full w-full bg-emerald-100 flex items-center justify-center text-emerald-600">
                    <Users className="h-5 w-5" />
                  </div>
                )}
              </div>
            ) : (
              <>
                <img src={otherUser?.photoURL || 'https://via.placeholder.com/40'} alt="" className="h-10 w-10 rounded-full border border-slate-200" />
                {otherUser?.isOnline && (
                  <div className="absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full bg-emerald-500 border-2 border-white"></div>
                )}
              </>
            )}
          </div>
          <div className="min-w-0">
            <h3 className="font-bold text-slate-800 truncate leading-tight flex items-center gap-2">
              {chat.isGroup ? chat.groupName : otherUser?.displayName}
              {!chat.isGroup && otherUser?.status && (
                <span className="text-[10px] bg-slate-100 text-slate-500 px-2 py-0.5 rounded-full font-medium italic truncate max-w-[100px]">
                  {otherUser.status}
                </span>
              )}
            </h3>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">
              {chat.isGroup 
                ? `${chat.participants.length} ${t('members')}` 
                : (otherUser?.isOnline ? t('activeNow') : t('lastSeen'))}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 text-slate-400 mr-2">
          {selectionMode ? (
            <div className="flex items-center gap-2">
              <span className="text-emerald-600 text-xs font-bold bg-emerald-50 px-2 py-1 rounded-full border border-emerald-100">
                {selectedMessageIds.size}
              </span>
              <button 
                onClick={deleteSelectedMessages}
                className="text-red-500 hover:bg-red-50 p-2 rounded-xl transition-all"
                title="ডিলিট করুন"
              >
                <Trash2 className="h-5 w-5" />
              </button>
              <button 
                onClick={() => { setSelectionMode(false); setSelectedMessageIds(new Set()); }}
                className="text-slate-400 hover:bg-slate-100 p-2 rounded-xl"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
          ) : (
            <>
              {!chat.isGroup && (
                <>
                  <button 
                    onClick={() => {
                      if (isBlocked || amIBlocked) {
                        alert(isBlocked ? "ইউজার ব্লকড। আগে আনব্লক করুন।" : t('আপনি ব্লকড। কল করা যাবে না।'));
                        return;
                      }
                      startCall('video');
                    }} 
                    className={`transition-all p-2.5 rounded-xl ${isBlocked || amIBlocked ? 'opacity-50 cursor-not-allowed text-slate-300' : 'hover:text-emerald-500 hover:bg-emerald-50'}`}
                  >
                    <Video className="h-5 w-5" />
                  </button>
                  <button 
                    onClick={() => {
                      if (isBlocked || amIBlocked) {
                        alert(isBlocked ? "ইউজার ব্লকড। আগে আনব্লক করুন।" : t('আপনি ব্লকড। কল করা যাবে না।'));
                        return;
                      }
                      startCall('audio');
                    }} 
                    className={`transition-all p-2.5 rounded-xl ${isBlocked || amIBlocked ? 'opacity-50 cursor-not-allowed text-slate-300' : 'hover:text-blue-500 hover:bg-blue-50'}`}
                  >
                    <Phone className="h-5 w-5" />
                  </button>
                </>
              )}
                <div className="relative">
                  <button 
                    onClick={() => setShowHeaderMenu(!showHeaderMenu)} 
                    className={`p-2.5 rounded-xl transition-colors ${showHeaderMenu ? 'bg-slate-200 text-slate-800' : 'hover:bg-slate-100 text-slate-400'}`}
                  >
                    <MoreVertical className="h-5 w-5" />
                  </button>
                  
                  <AnimatePresence>
                    {showHeaderMenu && (
                      <motion.div 
                        initial={{ opacity: 0, scale: 0.95, y: 10 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.95, y: 10 }}
                        className="absolute right-0 top-full mt-2 w-48 bg-white rounded-2xl shadow-2xl border border-slate-100 py-2 z-50 overflow-hidden"
                      >
                        {!chat.isGroup && (
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              toggleBlock();
                            }}
                            className={`w-full flex items-center gap-3 px-4 py-3 text-sm font-semibold transition-colors ${
                              isBlocked ? 'text-emerald-600 hover:bg-emerald-50' : 'text-red-600 hover:bg-red-50'
                            }`}
                          >
                            {isBlocked ? (
                              <>
                                <Unlock className="h-4 w-4" />
                                আনব্লক করুন
                              </>
                            ) : (
                              <>
                                <Ban className="h-4 w-4" />
                                ব্লক করুন
                              </>
                            )}
                          </button>
                        )}
                        <button 
                          onClick={() => setSelectionMode(true)}
                          className="w-full flex items-center gap-3 px-4 py-3 text-sm font-semibold text-slate-600 hover:bg-slate-50 transition-colors"
                        >
                          <Check className="h-4 w-4" />
                          মেসেজ মার্ক করুন
                        </button>
                        <button 
                          className="w-full flex items-center gap-3 px-4 py-3 text-sm font-semibold text-red-600 hover:bg-red-50 transition-colors"
                          onClick={clearChat}
                        >
                          <Trash2 className="h-4 w-4" />
                          চ্যাট ক্লিয়ার করুন
                        </button>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
            </>
          )}
        </div>
      </div>

      {/* Messages */}
      <div 
        ref={scrollRef}
        className="flex-grow overflow-y-auto px-4 py-6 space-y-2 bg-[url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png')] bg-repeat"
      >
        <div className="mx-auto w-fit bg-emerald-50 text-[10px] uppercase font-bold text-emerald-800 px-3 py-1 rounded-md shadow-sm mb-6 border border-emerald-100">
          আপনার মেসেজগুলো সুরক্ষিত এবং এনক্রিপ্টেড
        </div>

        {typingUsers.length > 0 && (
          <div className="flex items-center gap-2 mb-4 animate-pulse">
            <div className="flex gap-1">
              <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
              <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
              <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
            </div>
            <p className="text-xs text-slate-500 font-medium">
              {typingUsers.length === 1 
                ? `${typingUsers[0]} লিখছেন...` 
                : `${typingUsers.length} জন লিখছেন...`}
            </p>
          </div>
        )}
        
        {filteredMessages.map((msg) => {
          const isMe = msg.senderId === user?.uid;
          const isDeleted = msg.isDeletedForEveryone;

          return (
            <div 
              key={msg.id} 
              className={`flex items-center gap-3 ${isMe ? 'flex-row-reverse' : 'flex-row'}`}
              onClick={() => selectionMode && toggleMessageSelection(msg.id)}
            >
              {selectionMode && !isDeleted && (
                <div className={`h-5 w-5 rounded-md border-2 flex items-center justify-center transition-all shrink-0 ${selectedMessageIds.has(msg.id) ? 'bg-emerald-500 border-emerald-500' : 'border-slate-300'}`}>
                  {selectedMessageIds.has(msg.id) && <Check className="h-3 w-3 text-white" />}
                </div>
              )}
              <div 
                className={`max-w-[85%] px-3 py-1.5 rounded-lg shadow-sm relative group mb-1 ${
                  isMe 
                    ? 'bg-emerald-100 rounded-tr-none' 
                    : 'bg-white rounded-tl-none'
                } ${isDeleted ? 'opacity-70 italic' : ''} ${selectionMode && selectedMessageIds.has(msg.id) ? 'ring-2 ring-emerald-500 bg-emerald-50' : ''}`}
              >
                {chat.isGroup && !isMe && !isDeleted && (
                  <p className="text-[10px] font-bold text-emerald-600 mb-0.5">
                    {msg.senderName}
                  </p>
                )}
                {!isDeleted && !selectionMode && (
                  <button 
                    onClick={() => setShowOptionsId(showOptionsId === msg.id ? null : msg.id)}
                    className="absolute -top-1 -right-1 p-1 bg-white border border-slate-100 rounded-full shadow-sm opacity-0 group-hover:opacity-100 transition-opacity z-10"
                  >
                    <MoreVertical className="h-3 w-3 text-slate-400" />
                  </button>
                )}

                {showOptionsId === msg.id && (
                  <div className="absolute right-0 top-6 min-w-[150px] bg-white rounded-xl shadow-2xl border border-slate-100 z-50 overflow-hidden animate-in fade-in zoom-in duration-200">
                    <button 
                      onClick={() => deleteForMe(msg.id)}
                      className="w-full flex items-center gap-3 px-4 py-2.5 text-[13px] text-slate-600 hover:bg-slate-50 transition-colors border-b border-slate-50"
                    >
                      <Trash2 className="h-4 w-4" />
                      {t('deleteForMe')}
                    </button>
                    {msg.type === 'text' && (
                      <button 
                        onClick={() => handleTranslate(msg.id, msg.text)}
                        disabled={isTranslating === msg.id}
                        className="w-full flex items-center gap-3 px-4 py-2.5 text-[13px] text-emerald-600 hover:bg-emerald-50 transition-colors border-b border-slate-50"
                      >
                        <Languages className={`h-4 w-4 ${isTranslating === msg.id ? 'animate-spin' : ''}`} />
                        {translations[msg.id] ? t('original') : t('translate')}
                      </button>
                    )}
                    {isMe && (
                      <button 
                        onClick={() => deleteForEveryone(msg.id)}
                        className="w-full flex items-center gap-3 px-4 py-2.5 text-[13px] text-red-600 hover:bg-red-50 transition-colors"
                      >
                        <ShieldAlert className="h-4 w-4" />
                        {t('deleteForEveryone')}
                      </button>
                    )}
                  </div>
                )}

                {isDeleted ? (
                  <p className="text-[15px] break-words pr-12 text-slate-400 italic">
                    {msg.text}
                  </p>
                ) : (
                  <>
                    {msg.type === 'text' && (
                      <div className="space-y-2">
                        <p className="text-[15px] break-words pr-12 text-slate-800">
                          {msg.text}
                        </p>
                        {translations[msg.id] && (
                          <div className="mt-2 pt-2 border-t border-emerald-100/50">
                            <p className="text-[14px] text-emerald-700 italic pr-8">
                              {translations[msg.id]}
                            </p>
                            <span className="text-[9px] text-emerald-400 font-bold uppercase tracking-wider block mt-1">
                              {t('translated')} ({LANGUAGES.find(l => l.code === language)?.name})
                            </span>
                          </div>
                        )}
                        {isTranslating === msg.id && (
                          <div className="flex items-center gap-2 text-slate-400 py-1">
                            <Languages className="h-3 w-3 animate-spin" />
                            <span className="text-[11px]">{t('translating')}</span>
                          </div>
                        )}
                      </div>
                    )}

                    {msg.type === 'image' && msg.fileUrl && (
                      <div className="mt-1 mb-1 pr-8 relative group/img">
                        <img 
                          src={msg.fileUrl} 
                          alt="" 
                          className="max-w-full rounded-md shadow-sm border border-slate-100 max-h-[300px] object-cover cursor-pointer hover:opacity-95 transition-opacity" 
                          onClick={() => setFullScreenImage(msg.fileUrl!)}
                        />
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            downloadFile(msg.fileUrl!, `image_${msg.id}.png`);
                          }}
                          className="absolute bottom-2 right-10 p-2 bg-black/50 text-white rounded-full opacity-0 group-hover/img:opacity-100 transition-opacity hover:bg-black/70"
                          title={t('download')}
                        >
                          <Download className="h-4 w-4" />
                        </button>
                      </div>
                    )}

                    {msg.type === 'video' && msg.fileUrl && (
                      <div className="mt-1 mb-1 pr-8">
                        <video src={msg.fileUrl} controls className="max-w-full rounded-md shadow-sm border border-slate-100 max-h-[300px]" />
                      </div>
                    )}

                    {msg.type === 'audio' && msg.fileUrl && (
                      <div className="mt-1 mb-1 flex items-center gap-3 bg-emerald-50/50 p-2 rounded-lg min-w-[200px]">
                        <audio src={msg.fileUrl} controls className="h-8 w-full" />
                        {msg.duration && (
                          <span className="text-[10px] text-slate-400 font-bold whitespace-nowrap">
                            {Math.floor(msg.duration / 60)}:{(msg.duration % 60).toString().padStart(2, '0')}
                          </span>
                        )}
                      </div>
                    )}

                    {msg.type === 'call_info' && (
                      <div className="flex items-center gap-2 text-slate-500 text-sm py-1">
                        <Phone className="h-4 w-4" />
                        <span>{msg.text}</span>
                      </div>
                    )}
                  </>
                )}
                <span className="absolute bottom-1 right-2 text-[9px] text-slate-400 font-medium whitespace-nowrap flex items-center gap-0.5">
                  {format(msg.timestamp, 'HH:mm')}
                  {isMe && (
                    <div className="flex ml-1">
                      <Check className={`h-3 w-3 ${msg.readBy && msg.readBy.length > 1 ? 'text-blue-500' : 'text-slate-400'}`} />
                      <Check className={`h-3 w-3 -ml-2.5 ${msg.readBy && msg.readBy.length > 1 ? 'text-blue-500' : 'text-slate-400'}`} />
                    </div>
                  )}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Input */}
      {(isBlocked || amIBlocked) ? (
        <div className="bg-white/80 backdrop-blur-md p-6 text-center border-t border-slate-100 flex flex-col items-center gap-3">
          <div className="bg-slate-100 p-3 rounded-full text-slate-400">
            <ShieldAlert className="h-8 w-8" />
          </div>
          <p className="text-[15px] text-slate-600 font-bold max-w-[280px]">
            {isBlocked 
              ? 'আপনি এই ইউজারকে ব্লক করেছেন। মেসেজ পাঠাতে বা কল করতে হলে আগে আনব্লক করুন।' 
              : 'আপনি এই ইউজার দ্বারা ব্লকড। এই মুহূর্তে কোনো মেসেজ পাঠানো যাবে না।'}
          </p>
          {isBlocked && (
            <button 
              onClick={toggleBlock}
              className="mt-2 text-emerald-600 font-black text-xs uppercase tracking-widest border-2 border-emerald-600 px-6 py-2.5 rounded-full hover:bg-emerald-600 hover:text-white transition-all active:scale-95"
            >
              আনব্লক করুন
            </button>
          )}
        </div>
      ) : (
        <div className="relative">
          <AnimatePresence>
            {showEmojiPicker && (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 20 }}
                className="absolute bottom-full left-0 z-50 mb-2"
              >
                <EmojiPicker onEmojiClick={onEmojiClick} theme={Theme.LIGHT} />
              </motion.div>
            )}
          </AnimatePresence>
  
          <form onSubmit={sendMessage} className="bg-white/80 backdrop-blur-md p-2 flex items-center gap-2 border-t border-slate-100">
            <div className="flex gap-2 px-2">
              <button 
                type="button"
                onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                className={`p-2 rounded-full transition-colors ${showEmojiPicker ? 'bg-emerald-100 text-emerald-600' : 'text-slate-400 hover:bg-slate-100'}`}
              >
                <Smile className="h-6 w-6" />
              </button>
              <button 
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="p-2 text-slate-400 hover:bg-slate-100 rounded-full transition-colors"
              >
                <Paperclip className="h-6 w-6" />
              </button>
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleFileUpload}
                className="hidden" 
                accept="image/*,video/*"
              />
            </div>
  
            <div className="flex-grow flex items-center bg-slate-100 rounded-2xl px-4 py-2">
              {isRecording ? (
                <div className="flex items-center gap-3 w-full text-red-500 font-medium">
                  <motion.div 
                    animate={{ scale: [1, 1.2, 1] }} 
                    transition={{ repeat: Infinity }}
                    className="h-3 w-3 bg-red-500 rounded-full" 
                  />
                  <span className="text-sm">রেকর্ড হচ্ছে: {Math.floor(recordingTime / 60)}:{(recordingTime % 60).toString().padStart(2, '0')}</span>
                  <button 
                    type="button"
                    onClick={stopRecording}
                    className="ml-auto text-emerald-600 font-bold text-sm uppercase tracking-wider"
                  >
                    পাঠান
                  </button>
                </div>
              ) : (
                <input 
                  type="text" 
                  value={inputText}
                  onChange={handleInputChange}
                  onFocus={() => setShowEmojiPicker(false)}
                  placeholder="মেসেজ লিখুন..." 
                  className="flex-grow bg-transparent border-none focus:ring-0 text-[15px] outline-none py-1"
                />
              )}
            </div>
  
            <div className="px-2">
              {inputText.trim() ? (
                <button type="submit" className="bg-emerald-500 text-white p-3 rounded-full shadow-lg hover:bg-emerald-600 transition-all hover:scale-105 active:scale-95">
                  <Send className="h-5 w-5 fill-current" />
                </button>
              ) : (
                <button 
                  type="button"
                  onMouseDown={startRecording}
                  onMouseUp={stopRecording}
                  onTouchStart={startRecording}
                  onTouchEnd={stopRecording}
                  className={`p-3 rounded-full transition-all ${isRecording ? 'bg-red-500 text-white scale-125 animate-pulse' : 'bg-slate-100 text-slate-400 hover:bg-slate-200'}`}
                >
                  <Mic className="h-6 w-6" />
                </button>
              )}
            </div>
          </form>
        </div>
      )}

      {/* Call UI */}
      {activeCall && otherUser && (
        <CallInterface 
          type={activeCall.type}
          otherUser={otherUser}
          incoming={activeCall.incoming}
          onClose={() => setActiveCall(null)}
        />
      )}

      {/* Full Screen Image Viewer */}
      <AnimatePresence>
        {fullScreenImage && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[200] bg-black/90 flex flex-col items-center justify-center p-4 backdrop-blur-sm"
            onClick={() => setFullScreenImage(null)}
          >
            <button 
              className="absolute top-4 right-4 text-white hover:text-slate-300 p-3 bg-white/10 rounded-full transition-all"
              onClick={() => setFullScreenImage(null)}
            >
              <X className="h-8 w-8" />
            </button>
            <motion.img 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              src={fullScreenImage} 
              alt="" 
              className="max-w-full max-h-[85vh] object-contain shadow-2xl rounded-lg"
              onClick={(e) => e.stopPropagation()}
            />
            <div className="mt-8 flex gap-4">
              <button 
                className="bg-white/10 hover:bg-white/20 backdrop-blur-md text-white px-8 py-3 rounded-full flex items-center gap-3 transition-all font-bold border border-white/20 shadow-xl active:scale-95"
                onClick={(e) => {
                  e.stopPropagation();
                  downloadFile(fullScreenImage, `image_${Date.now()}.png`);
                }}
              >
                <Download className="h-5 w-5" />
                {t('download')}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Group Info Overlay */}
      <AnimatePresence>
        {showGroupInfo && (
          <motion.div 
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="absolute inset-0 z-[100] bg-white flex flex-col"
          >
            <div className="flex items-center gap-3 p-4 border-b border-slate-100">
              <button 
                onClick={() => {
                  setShowGroupInfo(false);
                  setEditingName(false);
                }} 
                className="p-2 hover:bg-slate-100 rounded-full text-slate-600"
              >
                <X className="h-6 w-6" />
              </button>
              <h2 className="text-xl font-black text-slate-800">{t('groupInfo')}</h2>
            </div>

            <div className="flex-grow overflow-y-auto bg-[#f8fafc]">
              <div className="bg-white p-8 flex flex-col items-center border-b border-slate-100 relative group/photo">
                <div className="relative h-32 w-32 mb-6">
                  {chat.groupPhotoURL ? (
                    <img src={chat.groupPhotoURL} alt="" className="h-32 w-32 rounded-full object-cover border-4 border-emerald-50 shadow-xl" />
                  ) : (
                    <div className="h-32 w-32 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600 border-4 border-emerald-50 shadow-xl">
                      <Users className="h-16 w-16" />
                    </div>
                  )}
                  {(chat.admins?.includes(user?.uid || '') || chat.createdBy === user?.uid) && (
                    <label className="absolute bottom-0 right-0 p-2 bg-emerald-500 rounded-full text-white shadow-lg cursor-pointer hover:bg-emerald-600 transition-all hover:scale-110">
                      <Camera className="h-5 w-5" />
                      <input type="file" className="hidden" accept="image/*" onChange={handleGroupPhotoUpload} />
                    </label>
                  )}
                </div>

                {editingName ? (
                  <div className="w-full max-w-sm flex flex-col gap-2">
                    <input 
                      type="text" 
                      value={newGroupName}
                      onChange={(e) => setNewGroupName(e.target.value)}
                      autoFocus
                      className="text-2xl font-black text-center border-b-2 border-emerald-500 bg-transparent py-1 outline-none text-slate-800"
                    />
                    <div className="flex justify-center gap-2 mt-2">
                      <button 
                        onClick={() => {
                          updateGroupMetadata({ groupName: newGroupName });
                          setEditingName(false);
                        }}
                        className="px-4 py-1.5 bg-emerald-500 text-white rounded-full text-sm font-bold shadow-md hover:bg-emerald-600"
                      >
                        {t('save')}
                      </button>
                      <button 
                        onClick={() => setEditingName(false)}
                        className="px-4 py-1.5 bg-slate-100 text-slate-600 rounded-full text-sm font-bold"
                      >
                        {t('cancel')}
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center gap-3">
                    <h1 className="text-2xl font-black text-slate-800">{chat.groupName}</h1>
                    {(chat.admins?.includes(user?.uid || '') || chat.createdBy === user?.uid) && (
                      <button onClick={() => setEditingName(true)} className="p-1.5 text-slate-400 hover:text-emerald-500 hover:bg-emerald-50 rounded-full transition-all">
                        <Edit3 className="h-5 w-5" />
                      </button>
                    )}
                  </div>
                )}
                <p className="text-slate-400 text-sm mt-1 font-medium italic">
                  {chat.participants.length} {t('members')}
                </p>
              </div>

              <div className="p-4 mt-4">
                <div className="flex items-center justify-between mb-4 px-2">
                  <h3 className="text-slate-500 font-bold uppercase tracking-widest text-xs">{t('members')}</h3>
                  <div className="h-px flex-grow mx-4 bg-slate-200"></div>
                </div>

                <div className="space-y-1">
                  {chat.participants.map(pId => {
                    const participant = chat.participantDetails?.[pId];
                    const isAdmin = chat.admins?.includes(pId) || chat.createdBy === pId;
                    const canIPromote = (chat.admins?.includes(user?.uid || '') || chat.createdBy === user?.uid) && !isAdmin;

                    return (
                      <div key={pId} className="flex items-center justify-between p-3 bg-white rounded-2xl border border-slate-50 shadow-sm mb-2 group">
                        <div className="flex items-center gap-3">
                          <img src={participant?.photoURL} alt="" className="h-10 w-10 rounded-full shadow-sm" />
                          <div>
                            <p className="font-bold text-slate-800 flex items-center gap-2">
                              {participant?.displayName}
                              {pId === user?.uid && <span className="text-[10px] bg-slate-100 text-slate-400 px-1.5 py-0.5 rounded uppercase">{t('you')}</span>}
                            </p>
                            {isAdmin && (
                              <p className="text-[10px] text-emerald-600 font-black uppercase flex items-center gap-1">
                                <ShieldCheck className="h-3 w-3" />
                                {t('admin')}
                              </p>
                            )}
                          </div>
                        </div>
                        
                        {canIPromote && (
                          <button 
                            onClick={() => promoteToAdmin(pId)}
                            className="text-xs bg-emerald-50 text-emerald-600 font-black px-3 py-1.5 rounded-full hover:bg-emerald-500 hover:text-white transition-all opacity-0 group-hover:opacity-100 flex items-center gap-1.5"
                          >
                            <UserPlus className="h-3 w-3" />
                            {t('promoteAdmin')}
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="p-4 mb-20 text-center">
                <p className="text-[10px] text-slate-300 font-bold uppercase tracking-widest">
                  তৈরি হয়েছে {format(chat.createdAt, 'dd MMM, yyyy')} তারিখে
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
