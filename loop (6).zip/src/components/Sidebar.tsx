import React, { useEffect, useState } from 'react';
import { collection, query, where, onSnapshot, orderBy, doc, getDoc, addDoc, serverTimestamp, deleteDoc, updateDoc, arrayUnion, arrayRemove } from 'firebase/firestore';
import { db, signOut } from './firebase';
import { useAuth } from './AuthContext';
import { ChatThread, UserProfile } from '../types';
import { LogOut, MessageSquarePlus, Search, User as UserIcon, MoreVertical, Phone, Video as VideoIcon, Heart, Star, Clock, PhoneMissed, PhoneForwarded, MessageSquare, Users, UserCircle, Settings, Share2, Check, Globe, Camera, Ban, Trash2, X, MoreHorizontal } from 'lucide-react';
import { format, isToday, isYesterday } from 'date-fns';
import { UserSearch } from './UserSearch';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage, LANGUAGES } from './LanguageContext';

interface CallLog {
  id: string;
  callerId: string;
  receiverId: string;
  type: 'audio' | 'video';
  status: string;
  createdAt: number;
  otherUser?: UserProfile;
}

interface SidebarProps {
  onSelectChat: (chat: ChatThread) => void;
  selectedChatId?: string;
  onStartCall: (type: 'audio' | 'video', targetUser: UserProfile) => void;
}

type TabType = 'chats' | 'calls' | 'contacts' | 'profile';

export const Sidebar: React.FC<SidebarProps> = ({ onSelectChat, selectedChatId, onStartCall }) => {
  const { user, profile } = useAuth();
  const { t, language, setLanguage } = useLanguage();
  const [chats, setChats] = useState<ChatThread[]>([]);
  const [callLogs, setCallLogs] = useState<CallLog[]>([]);
  const [activeTab, setActiveTab] = useState<TabType>('chats');
  const [selectionMode, setSelectionMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [showSearch, setShowSearch] = useState(false);
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);
  const [activeActionsId, setActiveActionsId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [copied, setCopied] = useState(false);
  const [userCache, setUserCache] = useState<Record<string, UserProfile>>({});

  const handleShare = async () => {
    const appUrl = window.location.origin;
    const shareText = `Loop-এ আমার সাথে যুক্ত হন! ${appUrl}`;
    
    // Check if native sharing is available
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Loop',
          text: 'Loop-এ আমার সাথে যুক্ত হন!',
          url: appUrl,
        });
        return; // Success
      } catch (err) {
        console.log("Native share canceled or failed:", err);
      }
    }

    // Fallback: Copy to clipboard
    try {
      await navigator.clipboard.writeText(appUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);

      // If on mobile and native share failed, try to open SMS
      if (/iPhone|Android/i.test(navigator.userAgent)) {
        window.open(`sms:?body=${encodeURIComponent(shareText)}`, '_blank');
      }
    } catch (err) {
      console.error("Clipboard fallback failed:", err);
    }
  };

  useEffect(() => {
    if (!user) return;

    // Listen for chats
    const qChats = query(
      collection(db, 'chats'),
      where('participants', 'array-contains', user.uid)
    );

    const unsubChats = onSnapshot(qChats, (snap) => {
      const chatList = snap.docs.map(doc => {
        const data = doc.data();
        return { 
          id: doc.id, 
          ...data,
          updatedAt: data.updatedAt?.toMillis ? data.updatedAt.toMillis() : data.updatedAt,
          createdAt: data.createdAt?.toMillis ? data.createdAt.toMillis() : data.createdAt,
          lastMessage: data.lastMessage ? {
            ...data.lastMessage,
            timestamp: data.lastMessage.timestamp?.toMillis ? data.lastMessage.timestamp.toMillis() : data.lastMessage.timestamp
          } : undefined
        } as ChatThread;
      });
      chatList.sort((a, b) => (Number(b.updatedAt) || 0) - (Number(a.updatedAt) || 0));
      setChats(chatList);
    }, (err) => {
      import('./firebase').then(({ handleFirestoreError, OperationType }) => {
        handleFirestoreError(err, OperationType.LIST, 'chats');
      });
    });

    // Listen for calls (both as caller and receiver)
    // We'll need two queries since Firestore doesn't support 'or' with different fields in a clean way for large sets easily without many indexes
    // But since this is a small-medium app, we can fetch recently ended calls where user was involved.
    
    // Query 1: As Caller
    const qCallsOut = query(
      collection(db, 'calls'),
      where('callerId', '==', user.uid)
    );

    // Query 2: As Receiver
    const qCallsIn = query(
      collection(db, 'calls'),
      where('receiverId', '==', user.uid)
    );

    const processCalls = (docs: any[]) => {
      return docs.map(d => {
        const data = d.data();
        return { 
          id: d.id, 
          ...data,
          createdAt: data.createdAt?.toMillis ? data.createdAt.toMillis() : data.createdAt
        } as CallLog;
      });
    };

    let callListIn: CallLog[] = [];
    let callListOut: CallLog[] = [];

    const updateAllCalls = () => {
      const combined = [...callListIn, ...callListOut];
      // Deduplicate by ID
      const deduplicated = Array.from(
        combined.reduce((map, call) => map.set(call.id, call), new Map()).values()
      );
      deduplicated.sort((a, b) => b.createdAt - a.createdAt);
      setCallLogs(deduplicated.slice(0, 50)); // Limit to last 50
    };

    const unsubCallsIn = onSnapshot(qCallsIn, (snap) => {
      callListIn = processCalls(snap.docs);
      updateAllCalls();
    }, (err) => {
      import('./firebase').then(({ handleFirestoreError, OperationType }) => {
        handleFirestoreError(err, OperationType.LIST, 'calls/in');
      });
    });

    const unsubCallsOut = onSnapshot(qCallsOut, (snap) => {
      callListOut = processCalls(snap.docs);
      updateAllCalls();
    }, (err) => {
      import('./firebase').then(({ handleFirestoreError, OperationType }) => {
        handleFirestoreError(err, OperationType.LIST, 'calls/out');
      });
    });

    return () => {
      unsubChats();
      unsubCallsIn();
      unsubCallsOut();
    };
  }, [user]);

  // Fetch profiles for call logs
  useEffect(() => {
    const fetchMissingProfiles = async () => {
      if (!user?.uid) return;
      
      const missingIds: string[] = Array.from(new Set(
        callLogs
          .map(call => call.callerId === user.uid ? call.receiverId : call.callerId)
          .filter(id => id && !userCache[id])
      ));

      if (missingIds.length === 0) return;

      for (const id of missingIds) {
        try {
          if (!user?.uid) break;
          const userDoc = await getDoc(doc(db, 'users', id));
          if (userDoc.exists()) {
            setUserCache(prev => ({
              ...prev,
              [id]: userDoc.data() as UserProfile
            }));
          }
        } catch (e) {
          console.warn("Silent profile fetch fail (Sidebar):", id);
        }
      }
    };

    fetchMissingProfiles();
  }, [callLogs, userCache, user?.uid]);

  const formatDate = (timestamp: number) => {
    if (isToday(timestamp)) return format(timestamp, 'HH:mm');
    if (isYesterday(timestamp)) return 'Yesterday';
    return format(timestamp, 'MMM d');
  };

  const toggleSelection = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const newSelected = new Set(selectedIds);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedIds(newSelected);
    if (newSelected.size === 0) setSelectionMode(false);
  };

  const deleteSelected = async () => {
    if (selectedIds.size === 0) return;
    const confirmMsg = activeTab === 'chats' 
      ? `আপনি কি নিশ্চিত যে ${selectedIds.size}টি চ্যাট ডিলিট করতে চান?` 
      : `আপনি কি নিশ্চিত যে ${selectedIds.size}টি কল রেকর্ড ডিলিট করতে চান?`;
    
    if (!window.confirm(confirmMsg)) return;

    const collectionName = activeTab === 'chats' ? 'chats' : 'calls';
    
    try {
      const promises = Array.from(selectedIds).map((id: string) => deleteDoc(doc(db, collectionName, id)));
      await Promise.all(promises);
      setSelectedIds(new Set());
      setSelectionMode(false);
    } catch (err: any) {
      console.error("Error deleting items:", err);
      const { handleFirestoreError, OperationType } = await import('./firebase');
      try {
        handleFirestoreError(err, OperationType.DELETE, collectionName);
      } catch (structuredErr: any) {
        alert("ডিলিট করার সময় সমস্যা হয়েছে: " + structuredErr.message);
      }
    }
  };

  const startNewChat = async (targetUser: UserProfile) => {
    if (!user) return;

    // Check if chat already exists
    const existing = chats.find(c => c.participants.includes(targetUser.uid));
    if (existing) {
      onSelectChat(existing);
      setShowSearch(false);
      return;
    }

    // Create new chat
    try {
      const newChatRef = await addDoc(collection(db, 'chats'), {
        participants: [user.uid, targetUser.uid],
        participantDetails: {
          [user.uid]: {
            uid: user.uid,
            displayName: user.displayName || 'Me',
            photoURL: user.photoURL || '',
            email: user.email || ''
          },
          [targetUser.uid]: targetUser
        },
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
      
      const newChatSnap = await getDoc(newChatRef);
      if (newChatSnap.exists()) {
        onSelectChat({ id: newChatSnap.id, ...newChatSnap.data() } as ChatThread);
      }
      setShowSearch(false);
    } catch (err) {
      console.error("Error creating chat:", err);
    }
  };

  const startNewGroupChat = async (selectedUsers: UserProfile[], groupName: string) => {
    if (!user) return;

    try {
      const participantIds = [user.uid, ...selectedUsers.map(u => u.uid)];
      const participantDetails: Record<string, UserProfile> = {
        [user.uid]: {
          uid: user.uid,
          displayName: user.displayName || 'Me',
          photoURL: user.photoURL || '',
          email: user.email || ''
        }
      };
      selectedUsers.forEach(u => {
        participantDetails[u.uid] = u;
      });

      const newChatRef = await addDoc(collection(db, 'chats'), {
        participants: participantIds,
        participantDetails,
        isGroup: true,
        groupName,
        createdBy: user.uid,
        admins: [user.uid],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
      
      const newChatSnap = await getDoc(newChatRef);
      if (newChatSnap.exists()) {
        onSelectChat({ id: newChatSnap.id, ...newChatSnap.data() } as ChatThread);
      }
      setShowSearch(false);
    } catch (err) {
      console.error("Error creating group chat:", err);
    }
  };

  const toggleFavorite = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!user || !profile) return;
    const isFavorite = profile.favoriteIds?.includes(id);
    const userRef = doc(db, 'users', user.uid);
    try {
      await updateDoc(userRef, {
        favoriteIds: isFavorite ? arrayRemove(id) : arrayUnion(id)
      });
    } catch (err) {
      console.error("Error toggling favorite:", err);
    }
  };

  const toggleBlock = async (targetId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!user || !profile) return;
    const isBlocked = profile.blockedUsers?.includes(targetId);
    const userRef = doc(db, 'users', user.uid);
    try {
      await updateDoc(userRef, {
        blockedUsers: isBlocked ? arrayRemove(targetId) : arrayUnion(targetId)
      });
      setActiveMenuId(null);
    } catch (err) {
      console.error("Error toggling block:", err);
    }
  };

  const deleteItem = async (id: string, type: 'chats' | 'calls', e: React.MouseEvent) => {
    e.stopPropagation();
    if (!window.confirm(`আপনি কি নিশ্চিত এই ${type === 'chats' ? 'চ্যাটটি' : 'কল রেকর্ডটি'} ডিলিট করতে চান?`)) return;
    try {
      await deleteDoc(doc(db, type, id));
    } catch (err: any) {
      console.error("Error deleting item:", err);
      const { handleFirestoreError, OperationType } = await import('./firebase');
      try {
        handleFirestoreError(err, OperationType.DELETE, type);
      } catch (structuredErr: any) {
        alert("ডিলিট করা সম্ভব হয়নি: " + structuredErr.message);
      }
    }
  };

  const handleRecordClick = (id: string, item: ChatThread | CallLog) => {
    if (selectionMode) {
      const newSelected = new Set(selectedIds);
      if (newSelected.has(id)) newSelected.delete(id);
      else newSelected.add(id);
      setSelectedIds(newSelected);
      if (newSelected.size === 0) setSelectionMode(false);
    } else if ('participants' in item) {
      // It's a chat
      onSelectChat(item as ChatThread);
    }
    // For calls, we don't necessarily do anything on main click if not in selection mode,
    // or we could start a call. Let's keep it simple.
  };

  return (
    <>
      {/* Header */}
      <div className="flex items-center justify-between bg-brand-gradient px-4 py-3 border-b border-white/10 shadow-lg">
        <div className="flex items-center gap-3">
          <div className="relative">
            <img src={profile?.photoURL || 'https://via.placeholder.com/40'} alt="Profile" className="h-10 w-10 rounded-full border-2 border-white/20" />
            <div className="absolute bottom-0 right-0 h-3 w-3 rounded-full bg-emerald-400 border-2 border-slate-900"></div>
          </div>
        <div>
          <h2 className="text-xl font-black text-white uppercase tracking-tighter italic">
            LO<span className="text-indigo-300">OP</span>
          </h2>
          <p className="text-[9px] text-white/50 font-bold uppercase tracking-widest leading-none">{activeTab}</p>
        </div>
        </div>
        <div className="flex gap-2">
          {selectionMode ? (
            <div className="flex items-center gap-2">
              <span className="text-white text-xs font-bold bg-white/20 px-2 py-1 rounded-full">
                {selectedIds.size}
              </span>
              <button 
                onClick={deleteSelected}
                className="text-white hover:text-red-400 p-2 bg-red-500/20 rounded-xl transition-all"
                title={t('delete')}
              >
                <Trash2 className="h-5 w-5" />
              </button>
              <button 
                onClick={() => { setSelectionMode(false); setSelectedIds(new Set()); }}
                className="text-white/70 hover:text-white p-2"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
          ) : (
            <>
              <button 
                onClick={handleShare}
                className="relative text-white/70 hover:text-emerald-400 transition-colors bg-white/10 p-2 rounded-xl"
                title="শেয়ার করুন"
              >
                <AnimatePresence mode="wait">
                  {copied ? (
                    <motion.div
                      key="check"
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      exit={{ scale: 0 }}
                    >
                      <Check className="h-5 w-5 text-emerald-400" />
                    </motion.div>
                  ) : (
                    <motion.div
                      key="share"
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      exit={{ scale: 0 }}
                    >
                      <Share2 className="h-5 w-5" />
                    </motion.div>
                  )}
                </AnimatePresence>
                
                <AnimatePresence>
                  {copied && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      className="absolute top-full mt-2 left-1/2 -translate-x-1/2 bg-emerald-500 text-white text-[10px] px-2 py-1 rounded shadow-lg whitespace-nowrap z-50 font-bold"
                    >
                      লিঙ্ক কপি হয়েছে!
                    </motion.div>
                  )}
                </AnimatePresence>
              </button>
            </>
          )}
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-grow overflow-y-auto bg-white flex flex-col">
        {activeTab === 'chats' && (
          <>
            {chats.length === 0 ? (
              <div className="flex flex-col items-center justify-center p-8 text-center text-slate-400 mt-20">
                <MessageSquare className="h-12 w-12 mb-4 opacity-20" />
                <p>কোনো মেসেজ নেই</p>
                <button 
                  onClick={() => setShowSearch(true)}
                  className="mt-4 text-emerald-600 font-semibold hover:underline"
                >
                  চ্যাট শুরু করুন
                </button>
              </div>
            ) : (
              chats.map(chat => {
                const otherUserId = chat.participants.find(p => p !== user?.uid);
                const otherUser = chat.participantDetails?.[otherUserId || ''];
                const isFavorite = profile?.favoriteIds?.includes(chat.id);
                
                return (
                  <div key={chat.id} className="relative group">
                    <div 
                      onClick={() => handleRecordClick(chat.id, chat)}
                      className={`flex items-center gap-3 px-4 py-3 cursor-pointer transition-colors border-b border-slate-50 hover:bg-[#f0f2f5] ${selectedChatId === chat.id ? 'bg-[#ebebeb]' : ''} ${selectedIds.has(chat.id) ? 'bg-emerald-50' : ''}`}
                    >
                      {selectionMode && (
                        <div className="flex-shrink-0">
                          <div className={`h-5 w-5 rounded-md border-2 flex items-center justify-center transition-all ${selectedIds.has(chat.id) ? 'bg-emerald-500 border-emerald-500' : 'border-slate-300'}`}>
                            {selectedIds.has(chat.id) && <Check className="h-3 w-3 text-white" />}
                          </div>
                        </div>
                      )}
                      <div className="relative">
                        {chat.isGroup ? (
                          <div className="h-12 w-12 rounded-full overflow-hidden border border-emerald-200">
                            {chat.groupPhotoURL ? (
                              <img src={chat.groupPhotoURL} alt="" className="h-full w-full object-cover" />
                            ) : (
                              <div className="h-full w-full bg-emerald-100 flex items-center justify-center text-emerald-600">
                                <Users className="h-6 w-6" />
                              </div>
                            )}
                          </div>
                        ) : (
                          <>
                            <img src={otherUser?.photoURL || 'https://via.placeholder.com/48'} alt="User" className={`h-12 w-12 rounded-full flex-shrink-0 object-cover border border-slate-100 ${profile?.blockedUsers?.includes(otherUserId || '') ? 'grayscale opacity-50' : ''}`} />
                            {profile?.blockedUsers?.includes(otherUserId || '') && (
                              <div className="absolute -bottom-1 -right-1 bg-red-500 p-0.5 rounded-full border-2 border-white shadow-sm">
                                <Ban className="h-2.5 w-2.5 text-white" />
                              </div>
                            )}
                          </>
                        )}
                        {isFavorite && (
                          <div className="absolute -top-1 -right-1 bg-amber-400 p-0.5 rounded-full border border-white shadow-sm">
                            <Star className="h-2.5 w-2.5 text-white fill-current" />
                          </div>
                        )}
                      </div>
                      
                      <div className="flex-grow min-w-0">
                        <div className="flex justify-between items-baseline">
                          <h3 className="font-semibold text-slate-800 truncate flex items-center gap-2">
                            {chat.isGroup ? chat.groupName : (otherUser?.displayName || 'Unknown User')}
                            {!chat.isGroup && otherUser?.status && (
                              <span className="text-[9px] text-emerald-500 font-medium italic truncate max-w-[60px]">
                                {otherUser.status}
                              </span>
                            )}
                          </h3>
                          <span className="text-[10px] text-slate-400 uppercase">
                            {chat.lastMessage ? formatDate(chat.lastMessage.timestamp) : ''}
                          </span>
                        </div>
                        
                        <div className="flex items-center gap-1">
                          <p className="text-sm text-slate-500 truncate flex-grow">
                            {chat.lastMessage ? chat.lastMessage.text : 'চ্যাট শুরু হয়নি'}
                          </p>
                          <button 
                            onClick={(e) => { e.stopPropagation(); setActiveMenuId(activeMenuId === chat.id ? null : chat.id); }}
                            className="p-1 text-slate-300 hover:text-slate-500 transition-colors"
                          >
                            <MoreVertical className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Three-dot menu items overlay */}
                    <AnimatePresence>
                      {activeMenuId === chat.id && (
                        <>
                          <div 
                            className="fixed inset-0 z-40" 
                            onClick={(e) => { e.stopPropagation(); setActiveMenuId(null); }}
                          />
                          <motion.div 
                            initial={{ opacity: 0, y: -10, scale: 0.95 }}
                            animate={{ opacity: 1, y: 0, scale: 1 }}
                            exit={{ opacity: 0, y: -10, scale: 0.95 }}
                            className="absolute bottom-2 right-12 bg-white shadow-2xl rounded-2xl border border-slate-100 z-50 py-2 w-48 overflow-hidden"
                          >
                            <button 
                              onClick={(e) => { e.stopPropagation(); setSelectionMode(true); setSelectedIds(new Set([chat.id])); setActiveMenuId(null); }}
                              className="w-full px-4 py-2.5 text-left hover:bg-slate-50 flex items-center gap-3 text-sm font-bold text-blue-600"
                            >
                              <Check className="h-4 w-4" />
                              {t('mark')}
                            </button>
                            <button 
                              onClick={(e) => { toggleFavorite(chat.id, e); setActiveMenuId(null); }}
                              className={`w-full px-4 py-2.5 text-left hover:bg-slate-50 flex items-center gap-3 text-sm font-bold ${isFavorite ? 'text-amber-500' : 'text-slate-600'}`}
                            >
                              <Star className={`h-4 w-4 ${isFavorite ? 'fill-current' : ''}`} />
                              {t('favorite')}
                            </button>
                            <button 
                              onClick={(e) => { deleteItem(chat.id, 'chats', e); setActiveMenuId(null); }}
                              className="w-full px-4 py-2.5 text-left hover:bg-slate-50 flex items-center gap-3 text-sm font-bold text-red-500"
                            >
                              <Trash2 className="h-4 w-4" />
                              {t('delete')}
                            </button>
                            {!chat.isGroup && otherUserId && (
                              <button 
                                onClick={(e) => toggleBlock(otherUserId, e)}
                                className="w-full px-4 py-2.5 text-left hover:bg-slate-50 flex items-center gap-3 text-sm font-bold text-red-700 border-t border-slate-50"
                              >
                                <Ban className="h-4 w-4" />
                                {profile?.blockedUsers?.includes(otherUserId) ? t('unblock') : t('block')}
                              </button>
                            )}
                          </motion.div>
                        </>
                      )}
                    </AnimatePresence>
                  </div>
                );
              })
            )}
          </>
        )}

        {activeTab === 'calls' && (
          <div className="flex flex-col h-full">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-white sticky top-0 z-10">
              <h2 className="font-bold text-slate-800 flex items-center gap-2">
                <Phone className="h-5 w-5 text-emerald-500" />
                কল হিস্ট্রি
              </h2>
              <button 
                onClick={() => setSelectionMode(!selectionMode)}
                className={`p-2 rounded-lg transition-all ${selectionMode ? 'bg-emerald-100 text-emerald-600' : 'text-slate-400 hover:bg-slate-100'}`}
                title="মার্ক করুন"
              >
                <Check className="h-5 w-5" />
              </button>
            </div>
            {callLogs.length === 0 ? (
              <div className="flex flex-col items-center justify-center p-8 text-center text-slate-400 mt-20">
                <Phone className="h-12 w-12 mb-4 opacity-20" />
                <p>কোনো কল নেই</p>
              </div>
            ) : (
              callLogs.map(call => {
                const otherId = call.callerId === user?.uid ? call.receiverId : call.callerId;
                const otherUser = userCache[otherId];
                const isOutgoing = call.callerId === user?.uid;
                const isMissed = !isOutgoing && call.status === 'missed';
                const isFavorite = profile?.favoriteIds?.includes(call.id);
                
                return (
                  <div key={call.id} className="relative group">
                    <div 
                      onClick={() => handleRecordClick(call.id, call)}
                      className={`flex items-center gap-3 px-4 py-3 border-b border-slate-50 hover:bg-[#f0f2f5] transition-colors group cursor-pointer ${selectedIds.has(call.id) ? 'bg-emerald-50' : ''}`}
                    >
                      {selectionMode && (
                        <div className="flex-shrink-0">
                          <div className={`h-5 w-5 rounded-md border-2 flex items-center justify-center transition-all ${selectedIds.has(call.id) ? 'bg-emerald-500 border-emerald-500' : 'border-slate-300'}`}>
                            {selectedIds.has(call.id) && <Check className="h-3 w-3 text-white" />}
                          </div>
                        </div>
                      )}
                      <div className="relative">
                        <img src={otherUser?.photoURL || 'https://via.placeholder.com/48'} alt="" className="h-12 w-12 rounded-full object-cover border border-slate-200" />
                        <div className="absolute -bottom-1 -right-1 p-1 rounded-full bg-white shadow-sm ring-1 ring-slate-100">
                          {call.type === 'video' ? <VideoIcon className="h-3 w-3 text-blue-500" /> : <Phone className="h-3 w-3 text-emerald-500" />}
                        </div>
                        {isFavorite && (
                          <div className="absolute -top-1 -right-1 bg-amber-400 p-0.5 rounded-full border border-white shadow-sm">
                            <Star className="h-2.5 w-2.5 text-white fill-current" />
                          </div>
                        )}
                      </div>
                      <div className="flex-grow min-w-0">
                        <h3 className={`font-semibold truncate text-sm ${isMissed ? 'text-red-500' : 'text-slate-800'}`}>
                          {otherUser?.displayName || 'অজানা কন্টাক্ট'}
                        </h3>
                        <div className="flex items-center gap-1.5 mt-0.5 text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                          {isOutgoing ? <PhoneForwarded className="h-3 w-3" /> : (isMissed ? <PhoneMissed className="h-3 w-3 text-red-400" /> : <Phone className="h-3 w-3" />)}
                          <span className={isMissed ? 'text-red-400' : ''}>
                            {isOutgoing ? t('outgoing') : (isMissed ? t('missed') : t('incoming'))} • {formatDate(call.createdAt)}
                          </span>
                        </div>
                      </div>

                      <div className="flex gap-1.5 ml-2">
                        <button 
                          onClick={(e) => { 
                            e.stopPropagation(); 
                            if (otherUser) onStartCall('audio', otherUser);
                          }}
                          className="p-2 text-emerald-500 hover:bg-emerald-50 rounded-xl transition-all"
                          title={t('callBack')}
                        >
                          <Phone className="h-5 w-5" />
                        </button>
                        <button 
                          onClick={(e) => { e.stopPropagation(); setActiveMenuId(activeMenuId === call.id ? null : call.id); }}
                          className="p-2 text-slate-300 hover:text-slate-500 transition-colors"
                        >
                          <MoreVertical className="h-5 w-5" />
                        </button>
                      </div>
                    </div>

                    {/* Three-dot menu overlay */}
                    <AnimatePresence>
                      {activeMenuId === call.id && (
                        <>
                          <div 
                            className="fixed inset-0 z-40" 
                            onClick={(e) => { e.stopPropagation(); setActiveMenuId(null); }}
                          />
                          <motion.div 
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.95 }}
                            className="absolute top-12 right-4 bg-white shadow-2xl rounded-2xl border border-slate-100 z-50 py-2 w-48 overflow-hidden"
                          >
                            <button 
                              onClick={(e) => { e.stopPropagation(); setSelectionMode(true); setSelectedIds(new Set([call.id])); setActiveMenuId(null); }}
                              className="w-full px-4 py-2.5 text-left hover:bg-slate-50 flex items-center gap-3 text-sm font-bold text-blue-600"
                            >
                              <Check className="h-4 w-4" />
                              {t('mark')}
                            </button>
                            <button 
                              onClick={(e) => { toggleFavorite(call.id, e); setActiveMenuId(null); }}
                              className={`w-full px-4 py-2.5 text-left hover:bg-slate-50 flex items-center gap-3 text-sm font-bold ${isFavorite ? 'text-amber-500' : 'text-slate-600'}`}
                            >
                              <Star className={`h-4 w-4 ${isFavorite ? 'fill-current' : ''}`} />
                              {t('favorite')}
                            </button>
                            <button 
                              onClick={(e) => { deleteItem(call.id, 'calls', e); setActiveMenuId(null); }}
                              className="w-full px-4 py-2.5 text-left hover:bg-slate-50 flex items-center gap-3 text-sm font-bold text-red-500"
                            >
                              <Trash2 className="h-4 w-4" />
                              {t('delete')}
                            </button>
                            {otherId && (
                              <button 
                                onClick={(e) => toggleBlock(otherId, e)}
                                className="w-full px-4 py-2.5 text-left hover:bg-slate-50 flex items-center gap-3 text-sm font-bold text-red-700 border-t border-slate-50"
                              >
                                <Ban className="h-4 w-4" />
                                {profile?.blockedUsers?.includes(otherId) ? t('unblock') : t('block')}
                              </button>
                            )}
                          </motion.div>
                        </>
                      )}
                    </AnimatePresence>
                  </div>
                );
              })
            )}
          </div>
        )}

        {activeTab === 'contacts' && (
          <div className="flex flex-col h-full bg-slate-50/30">
            <h2 className="p-4 font-bold text-slate-800 border-b border-slate-100 flex items-center gap-2 bg-white">
              <Users className="h-5 w-5 text-blue-500" />
              কন্টাক্ট লিস্ট
            </h2>
            <div className="p-4">
              <button 
                onClick={() => setShowSearch(true)}
                className="w-full flex items-center gap-3 bg-white p-3 rounded-xl border border-slate-100 shadow-sm hover:border-emerald-200 transition-all text-slate-600 font-medium"
              >
                <Search className="h-5 w-5 text-emerald-500" />
                নতুন বন্ধু খুঁজুন
              </button>
            </div>
            {/* Show people you already chat with as contacts */}
            <div className="flex-grow overflow-y-auto bg-white rounded-t-3xl border-t border-slate-100 shadow-sm">
              <h3 className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">আমার পরিচিতরা</h3>
              {chats.filter(chat => {
                const otherUserId = chat.participants.find(p => p !== user?.uid);
                const otherUser = chat.participantDetails?.[otherUserId || ''];
                return otherUser?.displayName.toLowerCase().includes(searchQuery.toLowerCase());
              }).map(chat => {
                const otherUserId = chat.participants.find(p => p !== user?.uid);
                const otherUser = chat.participantDetails?.[otherUserId || ''];
                return (
                  <div key={chat.id} onClick={() => onSelectChat(chat)} className="flex items-center gap-3 px-6 py-3 cursor-pointer hover:bg-slate-50 border-b border-slate-50 last:border-0">
                    <img src={otherUser?.photoURL || 'https://via.placeholder.com/40'} className="h-10 w-10 rounded-full" alt="" />
                    <span className="font-semibold text-slate-700">{otherUser?.displayName}</span>
                    <button className="ml-auto p-2 text-emerald-500 hover:bg-emerald-50 rounded-full">
                      <MessageSquare className="h-4 w-4" />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {activeTab === 'profile' && (
          <div className="flex flex-col h-full bg-slate-50/50">
            <h2 className="p-4 font-bold text-slate-800 border-b border-slate-100 mb-6 bg-white flex items-center gap-2">
               <UserCircle className="h-5 w-5 text-purple-500" />
               {t('profile')}
            </h2>
            <div className="flex flex-col items-center p-6 bg-white border-y border-slate-100 shadow-sm">
              <div className="relative mb-4 group">
                <img 
                  src={profile?.photoURL || 'https://via.placeholder.com/120'} 
                  alt="" 
                  className="h-24 w-24 rounded-full border-4 border-emerald-50 shadow-inner object-cover transition-all group-hover:opacity-75" 
                />
                <label className="absolute inset-0 flex items-center justify-center cursor-pointer opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="bg-black/40 p-2 rounded-full text-white backdrop-blur-sm">
                    <Camera className="h-5 w-5" />
                  </div>
                  <input 
                    type="file" 
                    className="hidden" 
                    accept="image/*"
                    onChange={async (e) => {
                      const file = e.target.files?.[0];
                      if (!file || !user) return;
                      
                      if (file.size > 800 * 1024) {
                        alert("অনুগ্রহ করে ৮০০ কেবি এর নিচের ছবি আপলোড করুন");
                        return;
                      }

                      const reader = new FileReader();
                      reader.onloadend = async () => {
                        const base64String = reader.result as string;
                        try {
                          const { doc, updateDoc } = await import('firebase/firestore');
                          const { db } = await import('./firebase');
                          await updateDoc(doc(db, 'users', user.uid), {
                            photoURL: base64String
                          });
                        } catch (err) {
                          console.error("Error updating photo:", err);
                        }
                      };
                      reader.readAsDataURL(file);
                    }}
                  />
                </label>
                <div className="absolute bottom-1 right-1 h-6 w-6 bg-emerald-500 rounded-full border-4 border-white shadow-sm" />
              </div>
              <h2 className="text-xl font-black text-slate-800">{profile?.displayName}</h2>
              <p className="text-sm text-slate-400 font-medium">{profile?.email}</p>
              {profile?.status && (
                <div className="mt-2 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-100 italic text-[11px] font-bold text-emerald-700">
                  "{profile.status}"
                </div>
              )}
            </div>

            <div className="mt-8 space-y-6 px-4 overflow-y-auto pb-8">
              {/* Status Section */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 px-2 text-xs font-bold text-slate-400 uppercase tracking-widest">
                  <Clock className="h-3.5 w-3.5" />
                  <span>{t('status')}</span>
                </div>
                <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm space-y-4">
                  <div className="flex flex-wrap gap-2">
                    {[t('available'), t('busy'), t('meeting')].map((s) => (
                      <button
                        key={s}
                        onClick={async () => {
                          if (!user) return;
                          try {
                            await updateDoc(doc(db, 'users', user.uid), { status: s });
                          } catch (err) {
                            console.error("Error updating status:", err);
                          }
                        }}
                        className={`text-[10px] font-bold px-3 py-1.5 rounded-full transition-all ${
                          profile?.status === s 
                            ? 'bg-emerald-500 text-white shadow-md' 
                            : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-100'
                        }`}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                  <div className="relative">
                    <input 
                      type="text" 
                      placeholder={t('customStatus')}
                      className="w-full bg-slate-50 border border-slate-100 rounded-lg px-3 py-2 text-xs outline-none focus:border-emerald-300 transition-colors"
                      onKeyDown={async (e) => {
                        if (e.key === 'Enter' && user) {
                          const target = e.target as HTMLInputElement;
                          try {
                            await updateDoc(doc(db, 'users', user.uid), { status: target.value });
                            target.value = '';
                          } catch (err) {
                            console.error("Error updating status:", err);
                          }
                        }
                      }}
                    />
                    <Check className="absolute right-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-300" />
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center gap-2 px-2 text-xs font-bold text-slate-400 uppercase tracking-widest">
                  <Globe className="h-3.5 w-3.5" />
                  <span>{t('language')}</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {LANGUAGES.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => setLanguage(lang.code as any)}
                      className={`flex items-center gap-2 p-3 rounded-xl border transition-all text-left ${
                        language === lang.code
                          ? 'bg-emerald-50 border-emerald-200 text-emerald-700 ring-2 ring-emerald-100'
                          : 'bg-white border-slate-100 text-slate-600 hover:border-slate-200'
                      }`}
                    >
                      <span className="text-lg">{lang.flag}</span>
                      <span className="text-xs font-bold truncate">{lang.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="bg-white p-4 rounded-xl shadow-sm flex items-center gap-4 text-slate-700 hover:bg-slate-50 cursor-pointer border border-slate-100">
                <Settings className="h-5 w-5 text-slate-400" />
                <span className="font-medium">অ্যাকাউন্ট সেটিংস</span>
              </div>
              
              <button 
                onClick={() => signOut()}
                className="w-full bg-white p-4 rounded-xl shadow-sm flex items-center gap-4 text-red-500 hover:bg-red-50 cursor-pointer border border-slate-100 transition-colors"
              >
                <LogOut className="h-5 w-5" />
                <span className="font-bold">{t('logout')}</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Navigation */}
      <div className="bg-white border-t border-slate-100 flex items-center justify-around py-3 px-2 shadow-[0_-4px_12px_rgba(0,0,0,0.03)] sticky bottom-0 z-20">
        {/* Calls */}
        <button 
          onClick={() => setActiveTab('calls')} 
          className={`flex flex-col items-center gap-1.5 transition-all duration-300 relative group ${activeTab === 'calls' ? 'text-amber-600 scale-110' : 'text-slate-400 hover:text-slate-600'}`}
        >
          <div className={`p-2 rounded-2xl transition-all ${activeTab === 'calls' ? 'bg-amber-50 shadow-sm' : ''}`}>
             <Phone className="h-6 w-6" />
          </div>
          <span className="text-[10px] font-black uppercase tracking-tighter whitespace-nowrap">{t('calls')}</span>
          {activeTab === 'calls' && <motion.div layoutId="nav-dot" className="absolute -top-1 h-1 w-4 bg-amber-600 rounded-full" />}
          {callLogs.some(c => c.status === 'missed' && c.receiverId === user?.uid) && (
             <span className="absolute top-0 right-0 h-3 w-3 bg-red-500 rounded-full border-2 border-white animate-pulse" />
          )}
        </button>

        {/* Contacts */}
        <button 
          onClick={() => { setActiveTab('contacts'); setSearchQuery(''); }} 
          className={`flex flex-col items-center gap-1.5 transition-all duration-300 relative group ${activeTab === 'contacts' ? 'text-blue-600 scale-110' : 'text-slate-400 hover:text-slate-600'}`}
        >
          <div className={`p-2 rounded-2xl transition-all ${activeTab === 'contacts' ? 'bg-blue-50 shadow-sm' : ''}`}>
             <Users className="h-6 w-6" />
          </div>
          <span className="text-[10px] font-black uppercase tracking-tighter">{t('contacts')}</span>
          {activeTab === 'contacts' && <motion.div layoutId="nav-dot" className="absolute -top-1 h-1 w-4 bg-blue-600 rounded-full" />}
        </button>

        {/* Messenger */}
        <button 
          onClick={() => { setActiveTab('chats'); setSearchQuery(''); }} 
          className={`flex flex-col items-center gap-1.5 transition-all duration-300 relative group ${activeTab === 'chats' ? 'text-emerald-600 scale-110' : 'text-slate-400 hover:text-slate-600'}`}
        >
          <div className={`p-2 rounded-2xl transition-all ${activeTab === 'chats' ? 'bg-emerald-50 shadow-sm' : ''}`}>
             <MessageSquare className="h-6 w-6" />
          </div>
          <span className="text-[10px] font-black uppercase tracking-tighter">{t('chats')}</span>
          {activeTab === 'chats' && <motion.div layoutId="nav-dot" className="absolute -top-1 h-1 w-4 bg-emerald-600 rounded-full" />}
        </button>

        {/* Profile */}
        <button 
          onClick={() => { setActiveTab('profile'); setSearchQuery(''); }} 
          className={`flex flex-col items-center gap-1.5 transition-all duration-300 relative group ${activeTab === 'profile' ? 'text-purple-600 scale-110' : 'text-slate-400 hover:text-slate-600'}`}
        >
          <div className={`p-2 rounded-2xl transition-all ${activeTab === 'profile' ? 'bg-purple-50 shadow-sm' : ''}`}>
             <UserCircle className="h-6 w-6" />
          </div>
          <span className="text-[10px] font-black uppercase tracking-tighter">{t('profile')}</span>
          {activeTab === 'profile' && <motion.div layoutId="nav-dot" className="absolute -top-1 h-1 w-4 bg-purple-600 rounded-full" />}
        </button>
      </div>

      <UserSearch 
        isOpen={showSearch} 
        onClose={() => setShowSearch(false)} 
        onSelectUser={startNewChat} 
        onSelectGroup={startNewGroupChat}
      />
    </>
  );
};
