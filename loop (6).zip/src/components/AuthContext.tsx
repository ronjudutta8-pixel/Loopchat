import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, onAuthStateChanged } from 'firebase/auth';
import { doc, setDoc, onSnapshot, serverTimestamp } from 'firebase/firestore';
import { auth, db } from './firebase';
import { UserProfile } from '../types';

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType>({ user: null, profile: null, loading: true });

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    return onAuthStateChanged(auth, async (user) => {
      setUser(user);
      if (user) {
        setLoading(true); // Ensure loading is true while we fetch
        const userRef = doc(db, 'users', user.uid);
        
        // Sync profile to Firestore
        try {
          // Wait a bit for SDK auth state to propagate fully to firestore internals
          await new Promise(r => setTimeout(r, 100));
          await setDoc(userRef, {
            uid: user.uid,
            displayName: user.displayName || user.email?.split('@')[0] || 'User',
            photoURL: user.photoURL || '',
            email: user.email || '',
            isOnline: true,
            lastSeen: serverTimestamp()
          }, { merge: true });
        } catch (err) {
          console.warn("Initial profile sync failed (silent), likely permission delay:", err);
        }

        // Listen for profile changes
        let isFirstFetch = true;
        const unsubscribe = onSnapshot(userRef, (snap) => {
          if (snap.exists()) {
            setProfile(snap.data() as UserProfile);
            if (isFirstFetch) {
              setLoading(false);
              isFirstFetch = false;
            }
          } else {
             // Profile doesn't exist yet, we still want to stop loading
             if (isFirstFetch) {
                setLoading(false);
                isFirstFetch = false;
             }
          }
        }, (err: any) => {
          const isPermissionError = err.code === 'permission-denied' || 
                                   err.message?.toLowerCase().includes('permission') ||
                                   err.message?.toLowerCase().includes('insufficient');
          
          if (isPermissionError) {
             console.log("Profile fetch permission denied (likely race or missing profile), waiting for sync...");
             // If we keep getting this for a while, stop loading anyway
             if (isFirstFetch) {
               setTimeout(() => { if (isFirstFetch) setLoading(false); }, 3000);
             }
          } else {
            console.error("Profile onSnapshot error:", err);
          }
        });
        
        // Safety timeout to stop loading if profile fetch hangs
        const timeout = setTimeout(() => {
          if (isFirstFetch) setLoading(false);
        }, 5000);

        return () => {
          clearTimeout(timeout);
          unsubscribe();
        };
      } else {
        setProfile(null);
        setLoading(false);
      }
    });
  }, []);

  return (
    <AuthContext.Provider value={{ user, profile, loading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
