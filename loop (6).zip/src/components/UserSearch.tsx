import React, { useState, useEffect } from 'react';
import { collection, query, where, getDocs, limit, startAt, endAt, orderBy } from 'firebase/firestore';
import { db } from './firebase';
import { UserProfile } from '../types';
import { Search, X, UserPlus, Users, ArrowRight, Check } from 'lucide-react';
import { useAuth } from './AuthContext';
import { motion, AnimatePresence } from 'motion/react';

interface UserSearchProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectUser: (user: UserProfile) => void;
  onSelectGroup: (users: UserProfile[], groupName: string) => void;
}

export const UserSearch: React.FC<UserSearchProps> = ({ isOpen, onClose, onSelectUser, onSelectGroup }) => {
  const { user: currentUser } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [results, setResults] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(false);
  const [isGroupMode, setIsGroupMode] = useState(false);
  const [selectedUsers, setSelectedUsers] = useState<UserProfile[]>([]);
  const [groupName, setGroupName] = useState('');

  const toggleUserSelection = (u: UserProfile) => {
    if (selectedUsers.some(existing => existing.uid === u.uid)) {
      setSelectedUsers(selectedUsers.filter(existing => existing.uid !== u.uid));
    } else {
      setSelectedUsers([...selectedUsers, u]);
    }
  };

  const handleGroupCreate = () => {
    if (selectedUsers.length === 0) return;
    if (!groupName.trim()) {
      alert("গ্রুপের নাম দিন");
      return;
    }
    onSelectGroup(selectedUsers, groupName);
    resetAndClose();
  };

  const resetAndClose = () => {
    setIsGroupMode(false);
    setSelectedUsers([]);
    setGroupName('');
    setSearchTerm('');
    onClose();
  };

  useEffect(() => {
    if (!searchTerm.trim()) {
      setResults([]);
      return;
    }

    const searchUsers = async () => {
      setLoading(true);
      try {
        if (!currentUser?.uid) return;
        const lowerSearch = searchTerm.toLowerCase();
        
        let usersList: UserProfile[] = [];

        // Try searching by displayName
        const qName = query(
          collection(db, 'users'),
          orderBy('displayName'),
          startAt(searchTerm),
          endAt(searchTerm + '\uf8ff'),
          limit(10)
        );
        
        try {
          const nameSnap = await getDocs(qName);
          usersList = nameSnap.docs.map(doc => doc.data() as UserProfile);
        } catch (e) {
          console.warn("Name search permission issue:", e);
        }

        // If email search looks promising, or we have few results
        if (usersList.length < 5) {
          try {
            const qEmail = query(
              collection(db, 'users'),
              orderBy('email'),
              startAt(searchTerm.toLowerCase()),
              endAt(searchTerm.toLowerCase() + '\uf8ff'),
              limit(10)
            );
            const emailSnap = await getDocs(qEmail);
            const emailResults = emailSnap.docs.map(doc => doc.data() as UserProfile);
            
            // Merge and avoid duplicates
            emailResults.forEach(u => {
              if (!usersList.some(existing => existing.uid === u.uid)) {
                usersList.push(u);
              }
            });
          } catch (e) {
            console.warn("Email search permission issue:", e);
          }
        }
        
        setResults(usersList.filter(u => u.uid !== currentUser?.uid).slice(0, 15));
      } catch (err) {
        console.error("Search error:", err);
      } finally {
        setLoading(false);
      }
    };

    const timer = setTimeout(searchUsers, 300);
    return () => clearTimeout(timer);
  }, [searchTerm, currentUser]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
      <motion.div 
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        className="w-full max-w-md bg-white rounded-2xl shadow-2xl overflow-hidden"
      >
        <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-emerald-600 text-white">
          <div className="flex items-center gap-2">
            {!isGroupMode ? (
              <h2 className="text-lg font-semibold">নতুন বন্ধু খুঁজুন</h2>
            ) : (
              <div className="flex items-center gap-2">
                <button onClick={() => setIsGroupMode(false)} className="p-1 hover:bg-emerald-500 rounded-full transition-colors">
                  <ArrowRight className="h-5 w-5 rotate-180" />
                </button>
                <h2 className="text-lg font-semibold">নতুন গ্রুপ খুলুন</h2>
              </div>
            )}
          </div>
          <button onClick={resetAndClose} className="p-1 hover:bg-emerald-500 rounded-full transition-colors">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="p-4 space-y-3">
          {!isGroupMode && (
            <button 
              onClick={() => setIsGroupMode(true)}
              className="w-full flex items-center gap-3 p-3 bg-emerald-50 text-emerald-700 rounded-xl hover:bg-emerald-100 transition-colors font-semibold"
            >
              <div className="bg-emerald-500 p-2 rounded-full text-white">
                <Users className="h-5 w-5" />
              </div>
              নতুন গ্রুপ মেসেজ খুলুন
            </button>
          )}

          {isGroupMode && (
            <div className="space-y-3">
              <input 
                type="text" 
                value={groupName}
                onChange={(e) => setGroupName(e.target.value)}
                placeholder="গ্রুপের নাম দিন..."
                className="w-full px-4 py-2.5 bg-slate-50 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
              />
              <div className="flex flex-wrap gap-2 max-h-24 overflow-y-auto">
                {selectedUsers.map(u => (
                  <div key={u.uid} className="flex items-center gap-1 bg-emerald-100 text-emerald-700 px-2 py-1 rounded-full text-xs font-semibold">
                    <span>{u.displayName}</span>
                    <button onClick={() => toggleUserSelection(u)}>
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <input 
              autoFocus
              type="text" 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="নাম বা ইমেইল দিয়ে খুঁজুন..." 
              className="w-full pl-10 pr-4 py-2.5 bg-slate-50 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
            />
          </div>
        </div>

        <div className="max-h-80 overflow-y-auto p-2">
          {loading ? (
            <div className="p-4 text-center text-slate-500">খোঁজা হচ্ছে...</div>
          ) : results.length > 0 ? (
            results.map(u => (
              <button
                key={u.uid}
                onClick={() => isGroupMode ? toggleUserSelection(u) : onSelectUser(u)}
                className={`w-full flex items-center gap-3 p-3 hover:bg-slate-50 rounded-xl transition-colors text-left ${selectedUsers.some(se => se.uid === u.uid) ? 'bg-emerald-50' : ''}`}
              >
                <div className="relative">
                  <img src={u.photoURL || 'https://via.placeholder.com/40'} alt="" className="h-10 w-10 rounded-full bg-slate-200" />
                  {selectedUsers.some(se => se.uid === u.uid) && (
                    <div className="absolute -bottom-1 -right-1 bg-emerald-500 text-white p-0.5 rounded-full border-2 border-white">
                      <Check className="h-3 w-3" />
                    </div>
                  )}
                </div>
                <div className="flex-grow">
                  <div className="font-semibold text-slate-800 flex items-center gap-2">
                    {u.displayName}
                    {u.status && (
                      <span className="text-[10px] bg-slate-100 text-slate-500 px-2 py-0.5 rounded-full font-medium italic truncate max-w-[80px]">
                        {u.status}
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-slate-500 truncate">{u.email}</div>
                </div>
                {!isGroupMode && <UserPlus className="h-5 w-5 text-emerald-500" />}
              </button>
            ))
          ) : searchTerm ? (
            <div className="p-8 text-center text-slate-400">কাউকে পাওয়া যায়নি</div>
          ) : (
            <div className="p-8 text-center text-slate-400">নাম বা ইমেইল লিখে খোঁজা শুরু করুন</div>
          )}
        </div>

        {isGroupMode && selectedUsers.length > 0 && (
          <div className="p-4 border-t border-slate-100 bg-slate-50">
            <button 
              onClick={handleGroupCreate}
              className="w-full py-3 bg-emerald-600 text-white rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-600/20 active:scale-95"
            >
              গ্রুপ খুলুন ({selectedUsers.length})
            </button>
          </div>
        )}
      </motion.div>
    </div>
  );
};
