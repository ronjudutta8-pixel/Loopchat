import { db, auth } from './components/firebase';
import { doc, updateDoc } from 'firebase/firestore';

export async function registerServiceWorker() {
  if ('serviceWorker' in navigator) {
    try {
      const registration = await navigator.serviceWorker.register('/sw.js');
      console.log('SW registered:', registration);
      return registration;
    } catch (error) {
      console.error('SW registration failed:', error);
    }
  }
}

export async function subscribeToPush(userId: string) {
  try {
    const permission = await Notification.requestPermission();
    if (permission !== 'granted') {
      console.log('Notification permission not granted');
      return;
    }

    const registration = await navigator.serviceWorker.ready;
    
    // Get public key from server
    const response = await fetch('/api/vapid-public-key');
    const { publicKey } = await response.json();
    
    if (!publicKey) {
       console.error('No VAPID public key available');
       return;
    }

    const subscription = await registration.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: publicKey
    });
    
    // Store in Firestore
    await updateDoc(doc(db, 'users', userId), {
      pushSubscription: JSON.parse(JSON.stringify(subscription))
    });
    
    console.log('User subscribed to push');
  } catch (error) {
    console.error('Push subscription failed:', error);
  }
}

export async function notifyCall(receiverSubscription: any, callId: string, callerName: string) {
  if (!receiverSubscription) {
    console.warn('No subscription found for receiver, skipping push');
    return;
  }
  
  try {
    const res = await fetch('/api/notify-call', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        subscription: receiverSubscription,
        callId,
        callerName
      })
    });
    const result = await res.json();
    console.log('Notify call response:', result);
  } catch (error) {
    console.error('Failed to send push notification:', error);
  }
}
