import { Handler } from "@netlify/functions";
import webpush from "web-push";

// Initialize web-push
const VAPID_PUBLIC_KEY = process.env.VAPID_PUBLIC_KEY || "";
const VAPID_PRIVATE_KEY = process.env.VAPID_PRIVATE_KEY || "";
let VAPID_EMAIL = process.env.VAPID_EMAIL || "mailto:example@example.com";

if (VAPID_EMAIL && !VAPID_EMAIL.startsWith("mailto:") && !VAPID_EMAIL.startsWith("http")) {
  VAPID_EMAIL = `mailto:${VAPID_EMAIL}`;
}

if (VAPID_PUBLIC_KEY && VAPID_PRIVATE_KEY) {
  try {
    webpush.setVapidDetails(VAPID_EMAIL, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY);
  } catch (error) {
    console.error("Failed to set VAPID details:", error);
  }
}

const handler: Handler = async (event, context) => {
  const path = event.path.replace(/\.netlify\/functions\/api/, "").replace(/\/api/, "");
  const method = event.httpMethod;

  // GET /api/vapid-public-key
  if (method === "GET" && (path === "/vapid-public-key" || path === "vapid-public-key")) {
    return {
      statusCode: 200,
      body: JSON.stringify({ publicKey: VAPID_PUBLIC_KEY }),
      headers: {
        "Content-Type": "application/json",
      },
    };
  }

  // POST /api/notify-call
  if (method === "POST" && (path === "/notify-call" || path === "notify-call")) {
    if (!event.body) {
      return { statusCode: 400, body: JSON.stringify({ error: "Missing body" }) };
    }

    const { subscription, title, body, callId, callerName } = JSON.parse(event.body);

    if (!subscription) {
      return { statusCode: 400, body: JSON.stringify({ error: "No subscription provided" }) };
    }

    const payload = JSON.stringify({
      title: title || "ইনকামিং কল",
      body: body || `${callerName} আপনাকে কল করছেন`,
      data: {
        url: `/?callId=${callId}`,
        callId
      },
      tag: `call-${callId}`,
      renotify: true,
      requireInteraction: true,
      actions: [
        { action: 'answer', title: 'Answer' },
        { action: 'decline', title: 'Decline' }
      ]
    });

    try {
      await webpush.sendNotification(subscription, payload);
      return {
        statusCode: 200,
        body: JSON.stringify({ success: true }),
        headers: { "Content-Type": "application/json" },
      };
    } catch (error) {
      console.error("Error sending push:", error);
      return {
        statusCode: 500,
        body: JSON.stringify({ error: "Failed to send notification" }),
        headers: { "Content-Type": "application/json" },
      };
    }
  }

  return {
    statusCode: 404,
    body: JSON.stringify({ error: "Route not found", path, method }),
  };
};

export { handler };
